# Sports Betting AI Platform - Design Style Guide

## Design Philosophy

### Visual Language: "Futuristic Sports Arena"
The design embodies the high-stakes, high-tech world of professional sports analytics, combining the excitement of a stadium atmosphere with the precision of a trading floor. Every element should feel premium, cutting-edge, and trustworthy - like the command center for professional sports betting.

### Color Palette: "Midnight Stadium"
- **Primary**: Deep Charcoal (#1a1a1a) - Professional, reduces eye strain during extended use
- **Secondary**: Electric Blue (#00d4ff) - AI predictions, data highlights, interactive elements
- **Accent**: Neon Green (#39ff14) - Success indicators, positive values, winning predictions
- **Warning**: Amber (#ffa500) - Medium confidence, caution indicators
- **Danger**: Coral Red (#ff6b6b) - Low confidence, losses, critical alerts
- **Neutral**: Steel Gray (#6c757d) - Supporting text, secondary information
- **Background**: Matte Black (#0d0d0d) - Main background, creates depth and focus

### Typography
- **Display Font**: "Orbitron" - Futuristic, tech-forward for headings and AI predictions
- **Body Font**: "Inter" - Clean, highly readable for data, statistics, and interface text
- **Monospace**: "JetBrains Mono" - Code-like precision for odds, statistics, and technical data

### Visual Hierarchy
- Large, bold headings with subtle glow effects
- Data-dense layouts with clear visual separation
- Color-coded information for quick scanning
- Progressive disclosure to prevent information overload

## Visual Effects & Animation

### 3D Graphics Implementation
- **Three.js Integration**: Stadium-style environment rendering
- **3D Team Logos**: Floating, rotating team emblems with metallic materials
- **Depth of Field**: Blur effects to focus attention on primary content
- **Particle Systems**: Subtle floating particles suggesting data flow and AI processing
- **3D Charts**: Interactive bar charts and radar graphs with real depth

### Animation Library Usage
- **Anime.js**: Smooth transitions, staggered animations for data loading
- **Matter.js**: Physics-based interactions for draggable bet slip items
- **PIXI.js**: High-performance visual effects for background elements
- **ECharts.js**: Interactive data visualizations with custom styling
- **p5.js**: Creative coding for background patterns and data art

### Text Effects
- **AI Prediction Reveal**: Typewriter effect with glowing text
- **Confidence Meters**: Animated progress bars with pulsing effects
- **Live Updates**: Color cycling for real-time data changes
- **Gradient Text**: Dynamic color shifts for emphasis
- **Split-by-letter**: Staggered reveals for important announcements

### Background Effects
- **Volumetric Noise**: Subtle fog/haze effect suggesting atmosphere
- **Grid Systems**: Animated data grids reminiscent of sports analytics displays
- **Light Rays**: Subtle volumetric lighting from top corners
- **Shader Effects**: Custom WebGL shaders for dynamic background patterns

### Hover Effects
- **3D Tilt**: Cards lift and rotate slightly on hover
- **Glow Expansion**: Interactive elements develop soft glows
- **Scale Transforms**: Subtle zoom effects (1.02x) for buttons
- **Color Morphing**: Smooth color transitions for state changes
- **Shadow Depth**: Dynamic shadows that respond to hover

### Interactive Elements Styling
- **Prediction Cards**: Glass-morphism with subtle transparency
- **Buttons**: Gradient backgrounds with animated borders
- **Data Tables**: Alternating row colors with hover highlights
- **Charts**: Interactive tooltips with smooth fade transitions
- **Navigation**: Sliding underline indicators

## Layout & Composition

### Grid System
- **12-column responsive grid** for precise alignment
- **Asymmetric layouts** to create visual interest
- **Card-based design** for modular content organization
- **Sidebar navigation** with collapsible panels

### Spacing & Rhythm
- **8px base unit** for consistent spacing
- **Generous whitespace** to prevent cognitive overload
- **Vertical rhythm** based on 24px line height
- **Component padding** minimum 16px for touch targets

### Visual Depth
- **Layered shadows** to create elevation hierarchy
- **Subtle gradients** for depth without overwhelming
- **Opacity variations** for background elements
- **Z-index management** for proper stacking

## Component Design Specifications

### Prediction Cards
- **Background**: Semi-transparent dark with subtle border
- **Border**: 1px solid rgba(0, 212, 255, 0.2)
- **Border Radius**: 12px
- **Shadow**: 0 8px 32px rgba(0, 212, 255, 0.1)
- **Hover State**: Border glow and slight lift

### AI Confidence Meters
- **Track**: Dark background with subtle gradient
- **Fill**: Animated gradient from red to green
- **Animation**: Smooth progress with pulse effect
- **Typography**: Large, bold numbers with percentage sign

### Data Visualization
- **Chart Colors**: Maximum 3 colors per visualization
- **Saturation**: Below 50% for professional appearance
- **Animation**: Staggered data point reveals
- **Interaction**: Hover tooltips with detailed information

### Navigation Elements
- **Active State**: Electric blue underline with glow
- **Hover State**: Subtle background color change
- **Typography**: Bold, all-caps for primary navigation
- **Spacing**: 24px between items

### Form Elements
- **Input Fields**: Dark background with blue focus border
- **Buttons**: Gradient backgrounds with hover animations
- **Checkboxes**: Custom styled with checkmark animations
- **Dropdowns**: Glass-morphism with smooth slide animations

## Responsive Design Principles

### Breakpoints
- **Mobile**: 320px - 768px
- **Tablet**: 768px - 1024px
- **Desktop**: 1024px - 1440px
- **Large Desktop**: 1440px+

### Mobile Adaptations
- **Simplified navigation** with hamburger menu
- **Stacked layouts** for better mobile viewing
- **Touch-friendly** interactive elements (44px minimum)
- **Reduced animations** for performance

### Performance Optimization
- **Lazy loading** for 3D graphics and heavy animations
- **Progressive enhancement** for advanced features
- **Optimized assets** with WebP images and compressed textures
- **Efficient rendering** with requestAnimationFrame

## Accessibility Considerations

### Color Contrast
- **Minimum 4.5:1** ratio for all text
- **High contrast mode** alternative
- **Color-blind friendly** palette choices
- **Never rely solely on color** for information

### Motion & Animation
- **Reduced motion** preferences respected
- **Optional animations** for users with vestibular disorders
- **Focus indicators** clearly visible
- **Skip navigation** links provided

### Screen Reader Support
- **Semantic HTML** structure
- **ARIA labels** for complex interactions
- **Alt text** for all images and graphics
- **Live regions** for dynamic content updates

## Brand Integration

### Logo Treatment
- **Primary logo**: Clean, modern wordmark
- **Favicon**: Simplified "AI" icon with sports ball
- **Loading animations**: Logo-based spinners
- **Watermarks**: Subtle branding on shared content

### Imagery Style
- **High contrast** photography with dramatic lighting
- **Consistent filtering** for brand cohesion
- **Professional sports** aesthetic
- **Minimal color overlays** to preserve image quality

This design system creates a cohesive, professional, and visually stunning platform that positions our sports betting AI as the premium choice for serious bettors while maintaining accessibility and usability across all devices.