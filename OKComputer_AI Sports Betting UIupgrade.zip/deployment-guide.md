# SportsPredict AI - Deployment Guide

## Quick Start Guide for Hostinger

### Step 1: Prepare Your Files
1. **Download the ZIP file** containing all platform files
2. **Extract the files** to your local computer
3. **Edit configuration** files with your API keys

### Step 2: Configure API Keys
Before uploading, you MUST configure your API keys:

1. Open `config.js` in a text editor
2. Add your API keys:

```javascript
const CONFIG = {
    API: {
        PRIMARY_API_KEY: 'your-api-sports-key-here',
        ODDS_API_KEY: 'your-odds-api-key-here',
        BACKUP_API_KEY: 'your-backup-api-key-here'
    }
};
```

3. **Get Free API Keys:**
   - API-SPORTS: https://api-sports.io/ (Free tier: 100 requests/day)
   - TheRundown: https://therundown.io/ (Free tier available)
   - SportsDataIO: https://sportsdata.io/ (Free trial)

### Step 3: Upload to Hostinger

#### Method A: File Manager (Recommended for beginners)
1. Log in to your Hostinger account
2. Go to **File Manager**
3. Navigate to **public_html** directory
4. Click **Upload Files**
5. Upload all files and folders
6. Ensure `index.html` is in the root directory

#### Method B: FTP Upload (For advanced users)
1. Connect to your Hostinger FTP server:
   - Host: `ftp.yourdomain.com` or server IP
   - Username: Your Hostinger username
   - Password: Your Hostinger password
   - Port: 21

2. Upload all files to the **public_html** directory

#### Method C: ZIP Upload (Fastest method)
1. Create a ZIP file with all platform files
2. Upload ZIP via Hostinger File Manager
3. Extract the ZIP file in File Manager

### Step 4: Verify Upload
1. Visit your domain: `https://yourdomain.com`
2. You should see the SportsPredict AI homepage
3. Test navigation to all pages
4. Check that images and styles load correctly

### Step 5: Test Functionality
1. **Test API Integration:**
   - Go to the dashboard
   - Check if live scores are updating
   - Verify odds are displayed

2. **Test Paper Trading:**
   - Navigate to Paper Trading
   - Place a test bet
   - Verify balance updates

3. **Test Audio:**
   - Click on various buttons
   - Check if sound effects play
   - Adjust volume settings

## File Structure on Server

```
public_html/
├── index.html                    # Main dashboard (homepage)
├── analytics.html                # Analytics page
├── paper-trading.html            # Basic paper trading
├── paper-trading-dashboard.html  # Enhanced paper trading
├── main.js                       # Core JavaScript
├── main-enhanced.js              # Enhanced application
├── api-manager.js                # API management
├── audio-manager.js              # Audio system
├── config.js                     # Configuration (EDIT THIS!)
├── resources/                    # Images and media
│   ├── logo-main.png
│   ├── stadium-hero.jpg
│   ├── analytics-bg.jpg
│   └── ...
├── README.md                     # Documentation
└── deployment-guide.md           # This file
```

## Configuration Steps

### 1. API Configuration (REQUIRED)
Edit `config.js` with your API keys:

```javascript
const CONFIG = {
    API: {
        PRIMARY_API_KEY: 'your-api-sports-key-here',    // Required for live scores
        ODDS_API_KEY: 'your-odds-api-key-here',          // Required for odds
        BACKUP_API_KEY: 'your-backup-api-key-here'       // Optional backup
    }
};
```

### 2. Audio Configuration (Optional)
Configure audio settings in `config.js`:

```javascript
const CONFIG = {
    AUDIO: {
        enabled: true,           // Enable/disable audio
        volume: 0.7              // Master volume (0.0 - 1.0)
    }
};
```

### 3. Streaming Configuration (Optional)
Enable streaming in `config.js`:

```javascript
const CONFIG = {
    STREAMING: {
        enabled: false,          // Set to true to enable
        providers: {
            twitch: 'https://player.twitch.tv/',
            youtube: 'https://www.youtube.com/embed/'
        }
    }
};
```

## Troubleshooting

### Common Issues and Solutions

#### 1. Page Not Loading
**Problem:** Website shows "Page Not Found" or "404 Error"

**Solutions:**
- Check that `index.html` is in the root directory
- Verify all files uploaded correctly
- Check file permissions (should be 644 for files, 755 for directories)
- Clear browser cache and try again

#### 2. API Data Not Loading
**Problem:** Live scores or odds not showing

**Solutions:**
- Verify API keys in `config.js` are correct
- Check if you've exceeded API rate limits
- Open browser Developer Tools (F12) and check Console for errors
- Ensure API keys are active and not expired

#### 3. Images Not Loading
**Problem:** Broken images or missing graphics

**Solutions:**
- Check that all files in `/resources/` folder uploaded
- Verify file permissions on images (should be 644)
- Check image file extensions (.jpg, .png, etc.)
- Try uploading images again

#### 4. JavaScript Errors
**Problem:** Features not working, console errors

**Solutions:**
- Open browser Developer Tools (F12) and check Console
- Look for error messages and line numbers
- Verify all JavaScript files uploaded correctly
- Check for missing semicolons or syntax errors

#### 5. Audio Not Working
**Problem:** No sound effects or audio feedback

**Solutions:**
- Check browser audio permissions
- Verify audio files exist in `/resources/audio/`
- Test on different browsers
- Check if audio is muted in config

#### 6. Mobile Display Issues
**Problem:** Site doesn't look good on mobile

**Solutions:**
- Add viewport meta tag to `<head>` section
- Test on actual mobile devices
- Use browser mobile emulation (F12 > Toggle Device Toolbar)
- Check for responsive design issues

### Performance Optimization

#### 1. Enable Compression
Add to `.htaccess` file:
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript
</IfModule>
```

#### 2. Set Cache Headers
Add to `.htaccess` file:
```apache
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType image/jpeg "access plus 1 month"
    ExpiresByType image/png "access plus 1 month"
</IfModule>
```

#### 3. Optimize Images
- Use WebP format for better compression
- Compress images before uploading
- Use appropriate image dimensions

### Security Best Practices

#### 1. Protect API Keys
- Never share API keys publicly
- Use environment variables for sensitive data
- Consider server-side proxy for API calls

#### 2. Use HTTPS
- Ensure SSL certificate is installed
- Force HTTPS redirects
- Add security headers

#### 3. File Permissions
Set proper file permissions:
```bash
# Files: 644 (read/write owner, read group/other)
# Directories: 755 (read/write/execute owner, read/execute group/other)
find . -type f -exec chmod 644 {} \;
find . -type d -exec chmod 755 {} \;
```

## Testing Checklist

### Before Going Live
- [ ] All API keys configured in `config.js`
- [ ] Images load correctly
- [ ] Navigation works on all pages
- [ ] Paper trading functions work
- [ ] Audio plays (if enabled)
- [ ] Mobile responsiveness works
- [ ] No JavaScript errors in console
- [ ] Site loads in under 3 seconds
- [ ] All links work correctly
- [ ] Forms submit properly

### After Going Live
- [ ] Test on multiple devices
- [ ] Test on multiple browsers
- [ ] Verify API data updates in real-time
- [ ] Check performance metrics
- [ ] Monitor for errors
- [ ] Test user workflows

## Support & Resources

### Documentation
- **README.md**: Complete platform documentation
- **API Documentation**: Links to API provider docs
- **Configuration Guide**: Detailed setup instructions

### Getting Help
1. **Check this guide** for common issues
2. **Review README.md** for feature documentation
3. **Check browser console** for error messages
4. **Verify API keys** are active and working
5. **Test with mock data** to isolate issues

### API Support
- **API-SPORTS**: https://api-sports.io/documentation
- **TheRundown**: https://therundown.io/documentation/
- **SportsDataIO**: https://sportsdata.io/developers

## Advanced Configuration

### Custom Domain Setup
1. **Point Domain**: Update DNS to point to Hostinger
2. **SSL Certificate**: Install SSL certificate for HTTPS
3. **Force HTTPS**: Add redirects from HTTP to HTTPS
4. **Test Configuration**: Verify everything works with custom domain

### CDN Integration (Optional)
For better performance, consider using a CDN:
1. **Cloudflare**: Free CDN with SSL
2. **AWS CloudFront**: Amazon's CDN service
3. **KeyCDN**: Pay-as-you-go CDN

### Database Integration (Advanced)
For advanced features, you can add database support:
1. **MySQL**: Hostinger provides MySQL databases
2. **PostgreSQL**: Advanced database option
3. **MongoDB**: NoSQL database option

## Monitoring & Analytics

### Performance Monitoring
Monitor these metrics:
- **Page Load Time**: Should be < 3 seconds
- **API Response Time**: Should be < 500ms
- **Error Rate**: Should be < 1%
- **Uptime**: Should be > 99%

### User Analytics
Consider adding analytics:
- **Google Analytics**: Free web analytics
- **Matomo**: Privacy-focused analytics
- **Custom Analytics**: Build your own tracking

## Backup & Recovery

### Regular Backups
1. **Automated Backups**: Set up automated daily backups
2. **Manual Backups**: Create backups before major changes
3. **Offsite Backups**: Store copies in multiple locations

### Recovery Procedures
1. **File Recovery**: Restore from backup if files are lost
2. **Database Recovery**: Restore database from backup
3. **Configuration Recovery**: Keep configuration backups separate

## Scaling & Growth

### Handling Traffic Spikes
1. **Caching**: Implement aggressive caching
2. **CDN**: Use CDN for static assets
3. **Load Balancing**: Consider load balancing for high traffic
4. **Database Optimization**: Optimize database queries

### Adding New Features
1. **Plan Feature**: Design and plan new functionality
2. **Test Locally**: Test on local development environment
3. **Staging Environment**: Test on staging before production
4. **Deploy Gradually**: Use feature flags for gradual rollout

## Compliance & Legal

### Legal Considerations
- **Gambling Laws**: Ensure compliance with local laws
- **Age Verification**: Implement age verification if required
- **Terms of Service**: Add terms of service page
- **Privacy Policy**: Add privacy policy page

### Accessibility
- **WCAG 2.1 AA**: Follow accessibility guidelines
- **Screen Readers**: Test with screen readers
- **Keyboard Navigation**: Ensure keyboard accessibility
- **Color Contrast**: Maintain proper contrast ratios

---

**Deployment Guide** - SportsPredict AI Platform
© 2025 SportsPredict AI. All rights reserved.