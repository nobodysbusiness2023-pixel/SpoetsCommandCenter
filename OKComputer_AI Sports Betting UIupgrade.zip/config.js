// SportsPredict AI - Configuration File
// Professional Sports Betting Platform Configuration

const CONFIG = {
    // API Configuration
    API: {
        // Primary Sports Data API (API-SPORTS)
        PRIMARY_API_KEY: 'YOUR_API_SPORTS_KEY_HERE', // Get free key from https://api-sports.io/
        PRIMARY_BASE_URL: 'https://v3.football.api-sports.io',
        
        // Secondary Odds API (TheRundown)
        ODDS_API_KEY: 'YOUR_ODDS_API_KEY_HERE', // Get key from https://therundown.io/
        ODDS_BASE_URL: 'https://therundown-api.herokuapp.com',
        
        // Backup API (SportsDataIO)
        BACKUP_API_KEY: 'YOUR_BACKUP_API_KEY_HERE',
        BACKUP_BASE_URL: 'https://api.sportsdata.io/v3',
        
        // Rate Limiting
        RATE_LIMIT: 100, // requests per day for free tier
        RATE_LIMIT_WINDOW: 86400000, // 24 hours in milliseconds
        
        // Update Intervals
        SCORES_UPDATE_INTERVAL: 15000, // 15 seconds
        ODDS_UPDATE_INTERVAL: 30000, // 30 seconds
        INJURIES_UPDATE_INTERVAL: 300000, // 5 minutes
    },
    
    // Sports Coverage
    SPORTS: {
        'americanfootball': {
            name: 'NFL',
            icon: '🏈',
            api_id: 1,
            active: true,
            sound_pack: 'football'
        },
        'basketball': {
            name: 'NBA',
            icon: '🏀',
            api_id: 2,
            active: true,
            sound_pack: 'basketball'
        },
        'baseball': {
            name: 'MLB',
            icon: '⚾',
            api_id: 3,
            active: true,
            sound_pack: 'baseball'
        },
        'icehockey': {
            name: 'NHL',
            icon: '🏒',
            api_id: 4,
            active: true,
            sound_pack: 'hockey'
        },
        'soccer': {
            name: 'Premier League',
            icon: '⚽',
            api_id: 39,
            active: true,
            sound_pack: 'soccer'
        }
    },
    
    // Audio Configuration
    AUDIO: {
        enabled: true,
        volume: 0.7,
        sound_packs: {
            football: {
                touchdown: 'resources/audio/football/td.mp3',
                field_goal: 'resources/audio/football/fg.mp3',
                interception: 'resources/audio/football/pick.mp3',
                crowd_cheer: 'resources/audio/football/cheer.mp3',
                whistle: 'resources/audio/football/whistle.mp3'
            },
            basketball: {
                buzzer_beater: 'resources/audio/basketball/buzzer.mp3',
                three_pointer: 'resources/audio/basketball/three.mp3',
                dunk: 'resources/audio/basketball/dunk.mp3',
                crowd_cheer: 'resources/audio/basketball/cheer.mp3',
                whistle: 'resources/audio/basketball/whistle.mp3'
            },
            baseball: {
                home_run: 'resources/audio/baseball/hr.mp3',
                strikeout: 'resources/audio/baseball/so.mp3',
                walk_off: 'resources/audio/baseball/walkoff.mp3',
                crowd_cheer: 'resources/audio/baseball/cheer.mp3',
                whistle: 'resources/audio/baseball/whistle.mp3'
            },
            hockey: {
                goal: 'resources/audio/hockey/goal.mp3',
                penalty: 'resources/audio/hockey/penalty.mp3',
                overtime: 'resources/audio/hockey/ot.mp3',
                crowd_cheer: 'resources/audio/hockey/cheer.mp3',
                whistle: 'resources/audio/hockey/whistle.mp3'
            },
            soccer: {
                goal: 'resources/audio/soccer/goal.mp3',
                penalty: 'resources/audio/soccer/penalty.mp3',
                red_card: 'resources/audio/soccer/redcard.mp3',
                crowd_cheer: 'resources/audio/soccer/cheer.mp3',
                whistle: 'resources/audio/soccer/whistle.mp3'
            }
        }
    },
    
    // Streaming Configuration
    STREAMING: {
        enabled: false, // Set to true when streaming API is available
        providers: {
            twitch: 'https://player.twitch.tv/',
            youtube: 'https://www.youtube.com/embed/',
            custom: 'https://streaming.sportspredict.ai/'
        },
        quality: '720p',
        autoplay: false,
        mute: true
    },
    
    // Paper Trading Configuration
    PAPER_TRADING: {
        starting_balance: 10000,
        currencies: ['USD', 'EUR', 'GBP', 'CAD'],
        default_currency: 'USD',
        max_bet_amount: 1000,
        min_bet_amount: 1,
        commission_rate: 0.05, // 5% commission
        
        // Achievement System
        achievements: {
            first_win: {
                name: 'First Win',
                description: 'Win your first bet',
                icon: '🏆',
                reward: 100,
                unlocked: false
            },
            win_streak_5: {
                name: '5-Game Streak',
                description: 'Win 5 bets in a row',
                icon: '🔥',
                reward: 500,
                unlocked: false
            },
            profit_1000: {
                name: '$1K Profit',
                description: 'Make $1,000 profit',
                icon: '💰',
                reward: 1000,
                unlocked: false
            },
            roi_10_percent: {
                name: '10% ROI',
                description: 'Achieve 10% ROI',
                icon: '📈',
                reward: 2000,
                unlocked: false
            },
            perfect_parlay: {
                name: 'Perfect Parlay',
                description: 'Win a 5+ leg parlay',
                icon: '🎯',
                reward: 5000,
                unlocked: false
            }
        }
    },
    
    // UI Configuration
    UI: {
        theme: 'dark',
        animations: true,
        sound_effects: true,
        refresh_interval: 15, // seconds
        
        // Chart Colors
        colors: {
            primary: '#00d4ff',
            secondary: '#39ff14',
            accent: '#ffa500',
            danger: '#ff6b6b',
            neutral: '#6c757d',
            background: '#0d0d0d',
            surface: '#1a1a1a'
        },
        
        // Notification Settings
        notifications: {
            enabled: true,
            desktop: true,
            sound: true,
            betting_alerts: true,
            score_updates: true,
            line_movements: true
        }
    },
    
    // Analysis Tools Configuration
    ANALYSIS: {
        enabled: true,
        features: {
            trend_analysis: true,
            value_bets: true,
            arbitrage_detector: true,
            bankroll_management: true,
            performance_tracking: true,
            betting_simulator: true
        },
        
        // Bankroll Management Rules
        bankroll_rules: {
            kelly_criterion: true,
            flat_betting: true,
            percentage_betting: true,
            confidence_based: true
        },
        
        // Performance Metrics
        metrics: {
            roi: true,
            win_rate: true,
            profit_loss: true,
            average_odds: true,
            streak_analysis: true,
            sport_performance: true,
            bet_type_performance: true
        }
    },
    
    // Security Configuration
    SECURITY: {
        encryption: true,
        rate_limiting: true,
        api_key_rotation: true,
        user_authentication: true,
        data_privacy: true
    },
    
    // Development Settings
    DEV: {
        debug: false,
        mock_data: true, // Set to false in production
        console_logging: true,
        performance_monitoring: true
    }
};

// Export configuration
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}

// Make CONFIG available globally
window.CONFIG = CONFIG;