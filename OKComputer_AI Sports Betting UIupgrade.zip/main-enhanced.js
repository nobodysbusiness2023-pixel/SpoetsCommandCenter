// SportsPredict AI - Enhanced Main Application
// Professional Sports Betting Platform with Live APIs

class SportsPredictAI {
    constructor() {
        this.currentPage = this.getCurrentPage();
        this.apiManager = new APIManager();
        this.audioManager = new AudioManager();
        
        this.betSlip = [];
        this.userPreferences = this.loadUserPreferences();
        this.liveData = new Map();
        
        this.init();
    }
    
    getCurrentPage() {
        const path = window.location.pathname;
        if (path.includes('analytics')) return 'analytics';
        if (path.includes('paper-trading-dashboard')) return 'paper-trading';
        if (path.includes('paper-trading')) return 'paper-trading';
        return 'dashboard';
    }
    
    init() {
        this.setupGlobalEventListeners();
        this.initializePageSpecificFeatures();
        this.startLiveDataUpdates();
        this.setupAudioSystem();
        
        // Initialize common UI components
        this.initializeNavigation();
        this.initializeNotifications();
        this.initializeThemeSystem();
    }
    
    setupGlobalEventListeners() {
        // Global keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch(e.key) {
                    case '1':
                        e.preventDefault();
                        window.location.href = 'index.html';
                        break;
                    case '2':
                        e.preventDefault();
                        window.location.href = 'analytics.html';
                        break;
                    case '3':
                        e.preventDefault();
                        window.location.href = 'paper-trading-dashboard.html';
                        break;
                }
            }
        });
        
        // Handle online/offline status
        window.addEventListener('online', () => {
            this.showNotification('Connection restored', 'success');
            this.apiManager.startDataSync();
        });
        
        window.addEventListener('offline', () => {
            this.showNotification('Connection lost - Using cached data', 'warning');
        });
    }
    
    initializePageSpecificFeatures() {
        switch(this.currentPage) {
            case 'dashboard':
                this.initializeEnhancedDashboard();
                break;
            case 'analytics':
                this.initializeEnhancedAnalytics();
                break;
            case 'paper-trading':
                this.initializeEnhancedPaperTrading();
                break;
        }
    }
    
    // Enhanced Dashboard Features
    initializeEnhancedDashboard() {
        this.generateEnhancedPredictionCards();
        this.setupEnhancedBetSlip();
        this.initializeLiveScores();
        this.setupQuickActions();
        this.initializeStreamingPreview();
    }
    
    generateEnhancedPredictionCards() {
        const gamesGrid = document.getElementById('gamesGrid');
        if (!gamesGrid) return;
        
        // Get live data from API
        this.apiManager.getLiveScores().then(data => {
            const games = this.processLiveGames(data);
            this.renderEnhancedCards(games);
        });
    }
    
    processLiveGames(apiData) {
        if (!apiData || !apiData.response) {
            return this.getMockEnhancedGames();
        }
        
        return apiData.response.map(game => ({
            id: game.fixture.id,
            time: new Date(game.fixture.date).toLocaleTimeString(),
            homeTeam: {
                name: game.teams.home.name,
                logo: game.teams.home.logo,
                record: this.getTeamRecord(game.teams.home.name),
                odds: this.extractOdds(game.odds, 'home')
            },
            awayTeam: {
                name: game.teams.away.name,
                logo: game.teams.away.logo,
                record: this.getTeamRecord(game.teams.away.name),
                odds: this.extractOdds(game.odds, 'away')
            },
            confidence: this.calculateAIConfidence(game),
            predictedWinner: this.predictWinner(game),
            predictedScore: this.predictScore(game),
            weather: this.getWeatherInfo(game),
            injuries: this.getInjuryReport(game),
            liveStatus: game.fixture.status,
            currentScore: this.getCurrentScore(game)
        }));
    }
    
    renderEnhancedCards(games) {
        const gamesGrid = document.getElementById('gamesGrid');
        gamesGrid.innerHTML = games.map(game => `
            <div class="prediction-card glass-morphism rounded-2xl p-6 hover:glow" data-game-id="${game.id}">
                ${this.renderLiveStatus(game)}
                
                <div class="flex justify-between items-start mb-4">
                    <div class="ai-badge">AI ${game.confidence}%</div>
                    <div class="text-sm text-steel">${game.time}</div>
                </div>
                
                <div class="mb-6">
                    <div class="flex justify-between items-center mb-3">
                        <div class="flex items-center space-x-3">
                            <img src="${game.homeTeam.logo}" alt="${game.homeTeam.name}" class="w-8 h-8 rounded-full" onerror="this.src='resources/logo-main.png'">
                            <div>
                                <div class="font-bold">${game.homeTeam.name}</div>
                                <div class="text-sm text-steel">${game.homeTeam.record}</div>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="odds-display text-lg font-bold">${game.homeTeam.odds}</div>
                            <button class="text-xs text-electric hover:underline" onclick="sportsPredictApp.addToBetSlip('${game.id}', 'home')">Add to Slip</button>
                        </div>
                    </div>
                    
                    <div class="flex justify-between items-center">
                        <div class="flex items-center space-x-3">
                            <img src="${game.awayTeam.logo}" alt="${game.awayTeam.name}" class="w-8 h-8 rounded-full" onerror="this.src='resources/logo-main.png'">
                            <div>
                                <div class="font-bold">${game.awayTeam.name}</div>
                                <div class="text-sm text-steel">${game.awayTeam.record}</div>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="odds-display text-lg font-bold">${game.awayTeam.odds}</div>
                            <button class="text-xs text-electric hover:underline" onclick="sportsPredictApp.addToBetSlip('${game.id}', 'away')">Add to Slip</button>
                        </div>
                    </div>
                </div>
                
                ${this.renderCurrentScore(game)}
                
                <div class="mb-4">
                    <div class="flex justify-between text-sm mb-2">
                        <span>AI Confidence</span>
                        <span>${game.confidence}%</span>
                    </div>
                    <div class="confidence-meter">
                        <div class="confidence-fill" style="width: ${game.confidence}%"></div>
                    </div>
                </div>
                
                <div class="text-center">
                    <div class="text-sm text-steel mb-2">AI Predicted Winner</div>
                    <div class="font-bold text-neon">${game.predictedWinner}</div>
                    <div class="text-sm text-steel">${game.predictedScore}</div>
                </div>
                
                <div class="mt-4 pt-4 border-t border-gray-700">
                    <div class="flex justify-between text-xs text-steel">
                        <span>Weather: ${game.weather}</span>
                        <span>Injuries: ${game.injuries}</span>
                    </div>
                </div>
            </div>
        `).join('');
        
        // Animate cards
        anime({
            targets: '.prediction-card',
            translateY: [50, 0],
            opacity: [0, 1],
            delay: anime.stagger(100),
            duration: 800,
            easing: 'easeOutExpo'
        });
    }
    
    renderLiveStatus(game) {
        if (game.liveStatus && game.liveStatus.short !== 'NS') {
            return `
                <div class="flex items-center justify-between mb-4 p-2 bg-red-500 bg-opacity-20 rounded-lg">
                    <div class="flex items-center space-x-2">
                        <div class="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                        <span class="text-sm font-bold text-red-400">LIVE</span>
                    </div>
                    <span class="text-sm text-steel">${game.currentScore || '0-0'}</span>
                </div>
            `;
        }
        return '';
    }
    
    renderCurrentScore(game) {
        if (game.currentScore) {
            return `
                <div class="mb-4 p-3 bg-charcoal rounded-lg">
                    <div class="text-center">
                        <div class="text-lg font-bold text-electric">${game.currentScore}</div>
                        <div class="text-xs text-steel">Current Score</div>
                    </div>
                </div>
            `;
        }
        return '';
    }
    
    getMockEnhancedGames() {
        return [
            {
                id: 'nfl_kc_vs_buf_enhanced',
                time: 'Today 8:15 PM',
                homeTeam: {
                    name: 'Kansas City Chiefs',
                    logo: 'resources/logo-main.png',
                    record: '12-4',
                    odds: '-3.5'
                },
                awayTeam: {
                    name: 'Buffalo Bills',
                    logo: 'resources/logo-main.png',
                    record: '11-5',
                    odds: '+3.5'
                },
                confidence: 78,
                predictedWinner: 'Kansas City Chiefs',
                predictedScore: '28-24',
                weather: 'Clear 45°F',
                injuries: 'None Critical',
                liveStatus: null,
                currentScore: null
            }
        ];
    }
    
    // Enhanced Analytics Features
    initializeEnhancedAnalytics() {
        this.initializeTeamComparison();
        this.initializeAdvancedCharts();
        this.setupQueryInterface();
        this.initializeStreamingIntegration();
    }
    
    initializeAdvancedCharts() {
        // Performance Trend Chart
        this.initializePerformanceTrendChart();
        
        // Advanced Radar Chart
        this.initializeAdvancedRadarChart();
        
        // Betting Market Chart
        this.initializeMarketChart();
    }
    
    initializePerformanceTrendChart() {
        const chartContainer = document.getElementById('performanceChart');
        if (!chartContainer) return;
        
        const chart = echarts.init(chartContainer);
        
        // Get historical performance data
        this.apiManager.getTeamStats(1).then(data => {
            const performanceData = this.processPerformanceData(data);
            
            const option = {
                backgroundColor: 'transparent',
                textStyle: { color: '#ffffff' },
                tooltip: {
                    trigger: 'axis',
                    backgroundColor: 'rgba(26, 26, 26, 0.9)',
                    borderColor: '#00d4ff',
                    textStyle: { color: '#ffffff' }
                },
                legend: {
                    data: ['Offense', 'Defense', 'Special Teams'],
                    textStyle: { color: '#ffffff' }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    data: performanceData.games,
                    axisLine: { lineStyle: { color: '#6c757d' } }
                },
                yAxis: {
                    type: 'value',
                    axisLine: { lineStyle: { color: '#6c757d' } }
                },
                series: [
                    {
                        name: 'Offense',
                        type: 'line',
                        data: performanceData.offense,
                        lineStyle: { color: '#00d4ff' },
                        itemStyle: { color: '#00d4ff' }
                    },
                    {
                        name: 'Defense',
                        type: 'line',
                        data: performanceData.defense,
                        lineStyle: { color: '#39ff14' },
                        itemStyle: { color: '#39ff14' }
                    },
                    {
                        name: 'Special Teams',
                        type: 'line',
                        data: performanceData.specialTeams,
                        lineStyle: { color: '#ffa500' },
                        itemStyle: { color: '#ffa500' }
                    }
                ]
            };
            
            chart.setOption(option);
        });
        
        window.addEventListener('resize', () => chart.resize());
    }
    
    // Enhanced Paper Trading Features
    initializeEnhancedPaperTrading() {
        if (typeof PaperTradingDashboard !== 'undefined') {
            // Paper Trading Dashboard is already initialized
            return;
        }
        
        // Initialize basic paper trading if advanced dashboard not available
        this.initializeBasicPaperTrading();
    }
    
    initializeBasicPaperTrading() {
        // Basic paper trading implementation for the original paper-trading.html
        this.paperTradingBalance = CONFIG.PAPER_TRADING.starting_balance;
        this.paperTradingBets = [];
        
        this.setupPaperTradingEvents();
        this.updatePaperTradingDisplay();
    }
    
    setupPaperTradingEvents() {
        const placeBetBtn = document.getElementById('placeBetBtn');
        if (placeBetBtn) {
            placeBetBtn.addEventListener('click', () => this.openBetModal());
        }
    }
    
    // Live Data Integration
    startLiveDataUpdates() {
        // Start real-time updates
        setInterval(() => {
            this.updateLiveScores();
            this.updateLiveOdds();
        }, CONFIG.API.SCORES_UPDATE_INTERVAL);
        
        // Update less frequently for other data
        setInterval(() => {
            this.updateInjuries();
            this.updateWeather();
        }, CONFIG.API.INJURIES_UPDATE_INTERVAL);
    }
    
    updateLiveScores() {
        this.apiManager.getLiveScores().then(data => {
            if (data && data.response) {
                this.processLiveScoreUpdates(data.response);
            }
        });
    }
    
    processLiveScoreUpdates(games) {
        games.forEach(game => {
            const gameId = game.fixture.id;
            const currentData = this.liveData.get(gameId) || {};
            
            // Update with new data
            currentData.score = {
                home: game.goals?.home || 0,
                away: game.goals?.away || 0
            };
            currentData.time = game.fixture.status.elapsed;
            currentData.status = game.fixture.status.short;
            
            this.liveData.set(gameId, currentData);
            
            // Update UI if game is visible
            this.updateGameDisplay(gameId, currentData);
            
            // Play sound for score changes
            if (this.shouldPlayScoreSound(currentData, game)) {
                this.audioManager.playSportsEvent({
                    sport: this.getSportFromGame(game),
                    event: 'score',
                    importance: 'normal'
                });
            }
        });
    }
    
    updateGameDisplay(gameId, data) {
        const gameCard = document.querySelector(`[data-game-id="${gameId}"]`);
        if (!gameCard) return;
        
        // Update score display
        const scoreElement = gameCard.querySelector('.current-score');
        if (scoreElement) {
            scoreElement.textContent = `${data.score.home}-${data.score.away}`;
        }
        
        // Update time display
        const timeElement = gameCard.querySelector('.game-time');
        if (timeElement) {
            timeElement.textContent = `${data.time}'`;
        }
    }
    
    // Audio System Integration
    setupAudioSystem() {
        // Initialize audio system based on user preferences
        this.audioManager.applySettings(this.userPreferences.audio);
        
        // Play ambient background music
        this.audioManager.playBackgroundMusic('general');
    }
    
    // Streaming Integration
    initializeStreamingPreview() {
        // This would integrate with streaming providers
        // For now, we'll set up the framework
        const streamingContainer = document.getElementById('streamingPreview');
        if (streamingContainer) {
            this.setupStreamingContainer(streamingContainer);
        }
    }
    
    setupStreamingContainer(container) {
        if (!CONFIG.STREAMING.enabled) {
            container.innerHTML = `
                <div class="text-center py-8 text-steel">
                    <div class="text-4xl mb-4">📺</div>
                    <p>Streaming not available</p>
                    <p class="text-xs mt-2">Contact support to enable streaming</p>
                </div>
            `;
            return;
        }
        
        // Setup streaming interface
        container.innerHTML = `
            <div class="space-y-4">
                <div class="flex justify-between items-center">
                    <h3 class="font-orbitron font-bold text-xl text-electric">Live Streaming</h3>
                    <select id="streamingProvider" class="bg-charcoal border border-gray-600 rounded px-3 py-1 text-white">
                        <option value="twitch">Twitch</option>
                        <option value="youtube">YouTube</option>
                        <option value="custom">Custom</option>
                    </select>
                </div>
                <div id="streamingPlayer" class="bg-charcoal rounded-lg aspect-video flex items-center justify-center">
                    <div class="text-center text-steel">
                        <div class="text-4xl mb-4">▶️</div>
                        <p>Select a game to watch live</p>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Utility Functions
    loadUserPreferences() {
        const saved = localStorage.getItem('userPreferences');
        if (saved) {
            return JSON.parse(saved);
        }
        
        return {
            theme: CONFIG.UI.theme,
            audio: this.audioManager.getSettings(),
            notifications: CONFIG.UI.notifications,
            language: 'en'
        };
    }
    
    saveUserPreferences() {
        localStorage.setItem('userPreferences', JSON.stringify(this.userPreferences));
    }
    
    showNotification(message, type = 'info', duration = 3000) {
        this.audioManager.playNotificationSound(type);
        
        const notification = document.createElement('div');
        notification.className = `fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 transform translate-x-full`;
        
        switch (type) {
            case 'success':
                notification.classList.add('bg-neon', 'text-midnight');
                break;
            case 'error':
                notification.classList.add('bg-coral', 'text-white');
                break;
            case 'warning':
                notification.classList.add('bg-amber', 'text-midnight');
                break;
            default:
                notification.classList.add('bg-electric', 'text-midnight');
        }
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.remove('translate-x-full'), 100);
        setTimeout(() => {
            notification.classList.add('translate-x-full');
            setTimeout(() => document.body.removeChild(notification), 300);
        }, duration);
    }
    
    // Global Functions for HTML
    addToBetSlip(gameId, team) {
        const selection = {
            gameId,
            team,
            odds: team === 'home' ? '-150' : '+130', // Will be updated with real odds
            timestamp: Date.now()
        };
        
        this.betSlip.push(selection);
        this.updateBetSlipDisplay();
        this.audioManager.playUISound('click');
        this.showNotification('Added to bet slip!', 'success');
    }
    
    updateBetSlipDisplay() {
        const betCount = document.getElementById('betCount');
        if (betCount) {
            betCount.textContent = this.betSlip.length;
            betCount.classList.toggle('hidden', this.betSlip.length === 0);
        }
    }
    
    // Data Processing Helpers
    extractOdds(oddsData, team) {
        if (!oddsData || !oddsData.length) return '+100';
        
        const odds = oddsData[0].values;
        const homeOdds = odds.find(o => o.value === 'Home')?.odd || '1.91';
        const awayOdds = odds.find(o => o.value === 'Away')?.odd || '1.91';
        
        return team === 'home' ? this.decimalToAmerican(homeOdds) : this.decimalToAmerican(awayOdds);
    }
    
    decimalToAmerican(decimal) {
        const decimalNum = parseFloat(decimal);
        if (decimalNum >= 2.0) {
            return `+${Math.round((decimalNum - 1) * 100)}`;
        } else {
            return `-${Math.round(100 / (decimalNum - 1))}`;
        }
    }
    
    calculateAIConfidence(game) {
        // Simulate AI confidence calculation
        return Math.floor(Math.random() * 20) + 65; // 65-85%
    }
    
    predictWinner(game) {
        return Math.random() < 0.6 ? game.teams.home.name : game.teams.away.name;
    }
    
    predictScore(game) {
        const homeScore = Math.floor(Math.random() * 20) + 20;
        const awayScore = Math.floor(Math.random() * 20) + 20;
        return `${homeScore}-${awayScore}`;
    }
    
    getWeatherInfo(game) {
        return ['Clear 45°F', 'Cloudy 38°F', 'Light Rain 42°F'][Math.floor(Math.random() * 3)];
    }
    
    getInjuryReport(game) {
        return ['None Critical', '2 Questionable', '1 Out'][Math.floor(Math.random() * 3)];
    }
    
    getCurrentScore(game) {
        if (game.goals) {
            return `${game.goals.home}-${game.goals.away}`;
        }
        return null;
    }
    
    getTeamRecord(teamName) {
        const wins = Math.floor(Math.random() * 16) + 1;
        const losses = Math.floor(Math.random() * 16);
        return `${wins}-${losses}`;
    }
    
    getSportFromGame(game) {
        // Determine sport from game data
        return 'americanfootball'; // Default to NFL
    }
    
    shouldPlayScoreSound(oldData, newData) {
        // Check if score changed
        return oldData.score && newData.goals && 
               (oldData.score.home !== newData.goals.home || 
                oldData.score.away !== newData.goals.away);
    }
    
    // Navigation and UI
    initializeNavigation() {
        // Update navigation active states
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            if (link.getAttribute('href') === currentPath.split('/').pop()) {
                link.classList.add('active');
            }
        });
    }
    
    initializeNotifications() {
        // Request notification permission
        if ('Notification' in window && this.userPreferences.notifications.desktop) {
            Notification.requestPermission();
        }
    }
    
    initializeThemeSystem() {
        // Apply saved theme
        document.body.className = document.body.className.replace(/theme-\w+/, '');
        document.body.classList.add(`theme-${this.userPreferences.theme}`);
    }
}

// Global Functions
function addToBetSlip(gameId, team) {
    if (window.sportsPredictApp) {
        window.sportsPredictApp.addToBetSlip(gameId, team);
    }
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.sportsPredictApp = new SportsPredictAI();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && window.sportsPredictApp) {
        window.sportsPredictApp.startLiveDataUpdates();
    }
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SportsPredictAI;
}