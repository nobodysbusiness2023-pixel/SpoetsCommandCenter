// SportsPredict AI - Paper Trading Dashboard
// Professional paper trading with comprehensive analytics

class PaperTradingDashboard {
    constructor() {
        this.portfolio = {
            balance: CONFIG.PAPER_TRADING.starting_balance,
            currency: CONFIG.PAPER_TRADING.default_currency,
            totalBets: 0,
            totalWon: 0,
            totalLost: 0,
            currentStreak: 0,
            bestStreak: 0,
            worstStreak: 0,
            totalProfit: 0,
            biggestWin: 0,
            biggestLoss: 0,
            averageOdds: 0,
            totalStaked: 0
        };
        
        this.betHistory = [];
        this.activeBets = [];
        this.achievements = [];
        this.analysisTools = {};
        
        this.apiManager = new APIManager();
        this.audioManager = new AudioManager();
        
        this.init();
    }
    
    init() {
        this.loadPortfolioData();
        this.setupEventListeners();
        this.initializeCharts();
        this.updateDashboard();
        this.startRealTimeUpdates();
        
        // Initialize analysis tools
        this.initializeAnalysisTools();
    }
    
    loadPortfolioData() {
        const saved = localStorage.getItem('paperTradingPortfolio');
        if (saved) {
            const data = JSON.parse(saved);
            this.portfolio = { ...this.portfolio, ...data.portfolio };
            this.betHistory = data.betHistory || [];
            this.activeBets = data.activeBets || [];
            this.achievements = data.achievements || [];
        }
    }
    
    savePortfolioData() {
        const data = {
            portfolio: this.portfolio,
            betHistory: this.betHistory,
            activeBets: this.activeBets,
            achievements: this.achievements,
            timestamp: Date.now()
        };
        
        localStorage.setItem('paperTradingPortfolio', JSON.stringify(data));
    }
    
    setupEventListeners() {
        // Quick action buttons
        document.getElementById('placeBetBtn')?.addEventListener('click', () => this.openBetModal());
        document.getElementById('viewActiveBets')?.addEventListener('click', () => this.filterBets('active'));
        document.getElementById('viewBetHistory')?.addEventListener('click', () => this.filterBets('history'));
        document.getElementById('analysisTools')?.addEventListener('click', () => this.openAnalysisModal());
        document.getElementById('achievementsBtn')?.addEventListener('click', () => this.showAchievements());
        
        // Filter buttons
        document.getElementById('filterAll')?.addEventListener('click', () => this.filterBetsTable('all'));
        document.getElementById('filterActive')?.addEventListener('click', () => this.filterBetsTable('active'));
        document.getElementById('filterSettled')?.addEventListener('click', () => this.filterBetsTable('settled'));
        
        // Analysis tool buttons
        document.getElementById('kellyCalculator')?.addEventListener('click', () => this.openAnalysisTool('kelly'));
        document.getElementById('valueBetFinder')?.addEventListener('click', () => this.openAnalysisTool('value'));
        document.getElementById('arbitrageScanner')?.addEventListener('click', () => this.openAnalysisTool('arbitrage'));
        document.getElementById('bankrollCalculator')?.addEventListener('click', () => this.openAnalysisTool('bankroll'));
        
        // Modal controls
        document.getElementById('closeAnalysisModal')?.addEventListener('click', () => this.closeAnalysisModal());
        
        // Export functionality
        document.getElementById('exportPortfolio')?.addEventListener('click', () => this.exportPortfolio());
    }
    
    initializeCharts() {
        this.initializePortfolioChart();
        this.initializePerformanceChart();
    }
    
    initializePortfolioChart() {
        const chartContainer = document.getElementById('portfolioChart');
        if (!chartContainer) return;
        
        const chart = echarts.init(chartContainer);
        
        // Generate historical data
        const dates = [];
        const values = [];
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - 30);
        
        let currentValue = CONFIG.PAPER_TRADING.starting_balance;
        
        for (let i = 0; i < 30; i++) {
            const date = new Date(startDate);
            date.setDate(date.getDate() + i);
            dates.push(date.toLocaleDateString());
            
            // Simulate portfolio changes based on actual bets
            const dailyChange = this.calculateDailyChange(date);
            currentValue += dailyChange;
            values.push(Math.max(0, currentValue));
        }
        
        const option = {
            backgroundColor: 'transparent',
            textStyle: { color: '#ffffff' },
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(26, 26, 26, 0.9)',
                borderColor: '#00d4ff',
                textStyle: { color: '#ffffff' },
                formatter: function(params) {
                    return `${params[0].axisValue}<br/>Portfolio Value: $${params[0].value.toLocaleString()}`;
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                data: dates,
                axisLine: { lineStyle: { color: '#6c757d' } },
                axisLabel: { rotate: 45, color: '#ffffff' }
            },
            yAxis: {
                type: 'value',
                axisLine: { lineStyle: { color: '#6c757d' } },
                axisLabel: {
                    color: '#ffffff',
                    formatter: '${value}'
                }
            },
            series: [{
                data: values,
                type: 'line',
                smooth: true,
                lineStyle: { color: '#00d4ff', width: 3 },
                itemStyle: { color: '#00d4ff' },
                areaStyle: {
                    color: {
                        type: 'linear',
                        x: 0, y: 0, x2: 0, y2: 1,
                        colorStops: [
                            { offset: 0, color: 'rgba(0, 212, 255, 0.3)' },
                            { offset: 1, color: 'rgba(0, 212, 255, 0.05)' }
                        ]
                    }
                }
            }]
        };
        
        chart.setOption(option);
        
        window.addEventListener('resize', () => chart.resize());
    }
    
    initializePerformanceChart() {
        const chartContainer = document.getElementById('performanceChart');
        if (!chartContainer) return;
        
        const chart = echarts.init(chartContainer);
        
        const performanceData = this.calculatePerformanceMetrics();
        
        const option = {
            backgroundColor: 'transparent',
            textStyle: { color: '#ffffff' },
            tooltip: {
                trigger: 'item',
                backgroundColor: 'rgba(26, 26, 26, 0.9)',
                borderColor: '#39ff14',
                textStyle: { color: '#ffffff' }
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                textStyle: { color: '#ffffff' }
            },
            series: [{
                name: 'Betting Performance',
                type: 'pie',
                radius: '50%',
                data: [
                    { 
                        value: performanceData.wins, 
                        name: 'Wins', 
                        itemStyle: { color: '#39ff14' } 
                    },
                    { 
                        value: performanceData.losses, 
                        name: 'Losses', 
                        itemStyle: { color: '#ff6b6b' } 
                    },
                    { 
                        value: performanceData.pending, 
                        name: 'Pending', 
                        itemStyle: { color: '#ffa500' } 
                    }
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(57, 255, 20, 0.5)'
                    }
                }
            }]
        };
        
        chart.setOption(option);
        
        window.addEventListener('resize', () => chart.resize());
    }
    
    calculateDailyChange(date) {
        // Calculate actual daily change from bet history
        const dayBets = this.betHistory.filter(bet => {
            const betDate = new Date(bet.date);
            return betDate.toDateString() === date.toDateString();
        });
        
        return dayBets.reduce((total, bet) => {
            return total + (bet.result === 'win' ? bet.profit : -bet.stake);
        }, 0);
    }
    
    calculatePerformanceMetrics() {
        const settledBets = this.betHistory.filter(bet => bet.result !== 'pending');
        const wins = settledBets.filter(bet => bet.result === 'win').length;
        const losses = settledBets.filter(bet => bet.result === 'loss').length;
        const pending = this.activeBets.length;
        
        return { wins, losses, pending };
    }
    
    updateDashboard() {
        this.updateKeyMetrics();
        this.updatePerformanceBreakdown();
        this.updateBetsTable();
        this.updateAchievements();
    }
    
    updateKeyMetrics() {
        // Current Balance
        const balanceElement = document.getElementById('currentBalance');
        const headerBalanceElement = document.getElementById('headerBalance');
        if (balanceElement) {
            balanceElement.textContent = `$${this.portfolio.balance.toLocaleString()}`;
        }
        if (headerBalanceElement) {
            headerBalanceElement.textContent = `$${this.portfolio.balance.toLocaleString()}`;
        }
        
        // Total Return
        const returnElement = document.getElementById('totalReturn');
        const startingBalance = CONFIG.PAPER_TRADING.starting_balance;
        const totalReturn = ((this.portfolio.balance - startingBalance) / startingBalance) * 100;
        if (returnElement) {
            returnElement.textContent = `${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(1)}%`;
            returnElement.className = totalReturn >= 0 ? 
                'text-3xl font-orbitron font-bold text-neon mb-2' : 
                'text-3xl font-orbitron font-bold text-coral mb-2';
        }
        
        // Win Rate
        const winRateElement = document.getElementById('winRate');
        const winLossElement = document.getElementById('winLossRecord');
        const winRate = this.portfolio.totalBets > 0 ? 
            (this.portfolio.totalWon / this.portfolio.totalBets) * 100 : 0;
        if (winRateElement) {
            winRateElement.textContent = `${winRate.toFixed(0)}%`;
        }
        if (winLossElement) {
            winLossElement.textContent = `${this.portfolio.totalWon}-${this.portfolio.totalLost}`;
        }
        
        // Current Streak
        const streakElement = document.getElementById('currentStreak');
        const streakTypeElement = document.getElementById('streakType');
        if (streakElement) {
            streakElement.textContent = Math.abs(this.portfolio.currentStreak);
            streakElement.className = this.portfolio.currentStreak >= 0 ? 
                'text-3xl font-orbitron font-bold win-streak mb-2' : 
                'text-3xl font-orbitron font-bold loss-streak mb-2';
        }
        if (streakTypeElement) {
            streakTypeElement.textContent = this.portfolio.currentStreak >= 0 ? 'Win Streak' : 'Loss Streak';
            streakTypeElement.className = this.portfolio.currentStreak >= 0 ? 
                'text-xs mt-1 win-streak' : 
                'text-xs mt-1 loss-streak';
        }
        
        // Update quick action metrics
        const activeBetsCountElement = document.getElementById('activeBetsCount');
        const totalBetsCountElement = document.getElementById('totalBetsCount');
        const achievementCountElement = document.getElementById('achievementCount');
        
        if (activeBetsCountElement) activeBetsCountElement.textContent = this.activeBets.length;
        if (totalBetsCountElement) totalBetsCountElement.textContent = this.portfolio.totalBets;
        if (achievementCountElement) achievementCountElement.textContent = this.achievements.length;
    }
    
    updatePerformanceBreakdown() {
        // Sport Performance
        const sportPerformanceElement = document.getElementById('sportPerformance');
        if (sportPerformanceElement) {
            const sportStats = this.calculateSportPerformance();
            sportPerformanceElement.innerHTML = sportStats.map(sport => `
                <div class="flex justify-between items-center p-3 bg-charcoal rounded-lg">
                    <div class="flex items-center space-x-3">
                        <span class="text-2xl">${sport.icon}</span>
                        <div>
                            <div class="font-bold">${sport.name}</div>
                            <div class="text-xs text-steel">${sport.bets} bets</div>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="font-mono font-bold ${sport.profit >= 0 ? 'text-neon' : 'text-coral'}">
                            ${sport.profit >= 0 ? '+' : ''}$${sport.profit.toFixed(0)}
                        </div>
                        <div class="text-xs text-steel">${sport.winRate}% WR</div>
                    </div>
                </div>
            `).join('');
        }
        
        // Bet Type Performance
        const betTypePerformanceElement = document.getElementById('betTypePerformance');
        if (betTypePerformanceElement) {
            const betTypeStats = this.calculateBetTypePerformance();
            betTypePerformanceElement.innerHTML = betTypeStats.map(type => `
                <div class="flex justify-between items-center p-3 bg-charcoal rounded-lg">
                    <div>
                        <div class="font-bold">${type.name}</div>
                        <div class="text-xs text-steel">${type.bets} bets</div>
                    </div>
                    <div class="text-right">
                        <div class="font-mono font-bold ${type.profit >= 0 ? 'text-neon' : 'text-coral'}">
                            ${type.profit >= 0 ? '+' : ''}$${type.profit.toFixed(0)}
                        </div>
                        <div class="text-xs text-steel">${type.winRate}% WR</div>
                    </div>
                </div>
            `).join('');
        }
    }
    
    calculateSportPerformance() {
        const sports = {};
        
        this.betHistory.forEach(bet => {
            if (!sports[bet.sport]) {
                sports[bet.sport] = {
                    name: bet.sport,
                    icon: CONFIG.SPORTS[bet.sport]?.icon || '🏈',
                    bets: 0,
                    wins: 0,
                    profit: 0
                };
            }
            
            sports[bet.sport].bets++;
            if (bet.result === 'win') {
                sports[bet.sport].wins++;
                sports[bet.sport].profit += bet.profit;
            } else if (bet.result === 'loss') {
                sports[bet.sport].profit -= bet.stake;
            }
        });
        
        return Object.values(sports).map(sport => ({
            ...sport,
            winRate: sport.bets > 0 ? Math.round((sport.wins / sport.bets) * 100) : 0
        }));
    }
    
    calculateBetTypePerformance() {
        const betTypes = {};
        
        this.betHistory.forEach(bet => {
            if (!betTypes[bet.type]) {
                betTypes[bet.type] = {
                    name: this.formatBetType(bet.type),
                    bets: 0,
                    wins: 0,
                    profit: 0
                };
            }
            
            betTypes[bet.type].bets++;
            if (bet.result === 'win') {
                betTypes[bet.type].wins++;
                betTypes[bet.type].profit += bet.profit;
            } else if (bet.result === 'loss') {
                betTypes[bet.type].profit -= bet.stake;
            }
        });
        
        return Object.values(betTypes).map(type => ({
            ...type,
            winRate: type.bets > 0 ? Math.round((type.wins / type.bets) * 100) : 0
        }));
    }
    
    formatBetType(type) {
        const types = {
            'moneyline': 'Moneyline',
            'spread': 'Point Spread',
            'total': 'Over/Under',
            'parlay': 'Parlay',
            'prop': 'Player Prop',
            'futures': 'Futures'
        };
        return types[type] || type;
    }
    
    updateBetsTable() {
        const betsTableElement = document.getElementById('betsTable');
        if (!betsTableElement) return;
        
        const allBets = [...this.activeBets, ...this.betHistory];
        
        if (allBets.length === 0) {
            betsTableElement.innerHTML = `
                <tr>
                    <td class="py-8 px-4 text-center text-steel" colspan="8">
                        <div class="text-4xl mb-4">🎯</div>
                        <p>No bets yet. Start trading!</p>
                    </td>
                </tr>
            `;
            return;
        }
        
        betsTableElement.innerHTML = allBets.map(bet => `
            <tr class="bet-card border-b border-gray-800">
                <td class="py-3 px-4 text-sm text-steel">${new Date(bet.date).toLocaleDateString()}</td>
                <td class="py-3 px-4 text-sm">
                    <div class="font-medium">${bet.game}</div>
                    <div class="text-xs text-steel">${bet.sport?.toUpperCase() || 'NFL'}</div>
                </td>
                <td class="py-3 px-4 text-sm">
                    <div class="font-medium">${bet.selection}</div>
                    <div class="text-xs text-steel">${this.formatBetType(bet.type)}</div>
                </td>
                <td class="py-3 px-4 text-sm font-mono text-electric">${bet.odds}</td>
                <td class="py-3 px-4 text-sm font-mono">$${bet.stake}</td>
                <td class="py-3 px-4 text-sm">
                    <span class="px-2 py-1 rounded text-xs font-medium ${
                        bet.result === 'win' ? 'bg-green-500 text-white' :
                        bet.result === 'loss' ? 'bg-red-500 text-white' :
                        'bg-yellow-500 text-black'
                    }">
                        ${bet.result === 'pending' ? 'Live' : bet.result?.toUpperCase() || 'PENDING'}
                    </span>
                </td>
                <td class="py-3 px-4 text-sm font-mono ${
                    bet.profit > 0 ? 'text-neon' :
                    bet.profit < 0 ? 'text-coral' :
                    'text-steel'
                }">
                    ${bet.result === 'pending' ? 'Pending' : 
                      bet.profit >= 0 ? `+$${bet.profit.toFixed(2)}` : 
                      `-$${Math.abs(bet.profit).toFixed(2)}`}
                </td>
                <td class="py-3 px-4 text-sm">
                    ${bet.result === 'pending' ? 
                        `<button class="text-coral hover:text-red-400 text-xs" onclick="paperTradingDashboard.cashOutBet('${bet.id}')">Cash Out</button>` :
                        `<button class="text-electric hover:text-blue-400 text-xs" onclick="paperTradingDashboard.viewBetDetails('${bet.id}')">Details</button>`
                    }
                </td>
            </tr>
        `).join('');
    }
    
    updateAchievements() {
        const achievementsElement = document.getElementById('recentAchievements');
        if (!achievementsElement) return;
        
        if (this.achievements.length === 0) {
            achievementsElement.innerHTML = `
                <div class="text-center text-steel py-8">
                    <div class="text-2xl mb-2">🏆</div>
                    <p>No achievements yet</p>
                    <p class="text-xs mt-1">Keep trading to unlock achievements!</p>
                </div>
            `;
            return;
        }
        
        achievementsElement.innerHTML = this.achievements.slice(-5).reverse().map(achievement => `
            <div class="flex items-center space-x-3 p-3 bg-charcoal rounded-lg">
                <span class="text-2xl">${achievement.icon}</span>
                <div class="flex-1">
                    <div class="font-bold text-sm">${achievement.name}</div>
                    <div class="text-xs text-steel">${achievement.description}</div>
                </div>
                <div class="text-xs text-steel">${new Date(achievement.date).toLocaleDateString()}</div>
            </div>
        `).join('');
    }
    
    // Analysis Tools
    initializeAnalysisTools() {
        this.analysisTools = {
            kelly: new KellyCalculator(),
            value: new ValueBetFinder(),
            arbitrage: new ArbitrageScanner(),
            bankroll: new BankrollManager()
        };
    }
    
    openAnalysisTool(toolType) {
        const modal = document.getElementById('analysisModal');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('analysisContent');
        
        const toolNames = {
            kelly: 'Kelly Criterion Calculator',
            value: 'Value Bet Finder',
            arbitrage: 'Arbitrage Scanner',
            bankroll: 'Bankroll Manager'
        };
        
        title.textContent = toolNames[toolType] || 'Analysis Tool';
        content.innerHTML = this.analysisTools[toolType].render();
        
        modal.classList.remove('hidden');
    }
    
    closeAnalysisModal() {
        document.getElementById('analysisModal').classList.add('hidden');
    }
    
    // Bet Management
    placeBet(betData) {
        const bet = {
            id: Date.now().toString(),
            date: new Date().toISOString(),
            game: betData.game,
            sport: betData.sport || 'americanfootball',
            type: betData.type,
            selection: betData.selection,
            odds: betData.odds,
            stake: betData.stake,
            result: 'pending',
            profit: 0,
            status: 'active'
        };
        
        // Deduct stake from balance
        this.portfolio.balance -= bet.stake;
        this.activeBets.push(bet);
        
        // Update portfolio stats
        this.portfolio.totalBets++;
        this.portfolio.totalStaked += bet.stake;
        
        // Save data
        this.savePortfolioData();
        this.updateDashboard();
        
        // Play sound
        this.audioManager.playBettingEvent({ event: 'bet_placed', amount: bet.stake });
        
        // Show notification
        this.showNotification(`Bet placed: $${bet.stake} on ${bet.selection}`, 'success');
        
        return bet;
    }
    
    settleBet(betId, result, actualScore = null) {
        const bet = this.activeBets.find(b => b.id === betId);
        if (!bet) return false;
        
        bet.result = result;
        bet.status = 'settled';
        
        if (result === 'win') {
            const profit = this.calculatePayout(bet.odds, bet.stake);
            bet.profit = profit - bet.stake;
            this.portfolio.balance += profit;
            this.portfolio.totalProfit += bet.profit;
            this.portfolio.totalWon++;
            
            // Update streak
            this.portfolio.currentStreak = Math.max(0, this.portfolio.currentStreak) + 1;
            this.portfolio.bestStreak = Math.max(this.portfolio.bestStreak, this.portfolio.currentStreak);
            
            // Play win sound
            this.audioManager.playBettingEvent({ 
                event: bet.type === 'parlay' ? 'parlay_won' : 'bet_won', 
                amount: bet.profit 
            });
            
            // Check for achievements
            this.checkBettingAchievements(bet);
            
        } else if (result === 'loss') {
            bet.profit = -bet.stake;
            this.portfolio.totalProfit += bet.profit;
            this.portfolio.totalLost++;
            
            // Update streak
            this.portfolio.currentStreak = Math.min(0, this.portfolio.currentStreak) - 1;
            this.portfolio.worstStreak = Math.min(this.portfolio.worstStreak, this.portfolio.currentStreak);
            
            // Play loss sound
            this.audioManager.playBettingEvent({ event: 'bet_lost', amount: bet.stake });
        }
        
        // Move to bet history
        this.activeBets = this.activeBets.filter(b => b.id !== betId);
        this.betHistory.unshift(bet);
        
        // Update average odds
        this.updateAverageOdds();
        
        // Save data
        this.savePortfolioData();
        this.updateDashboard();
        
        return true;
    }
    
    calculatePayout(odds, stake) {
        if (odds.startsWith('+')) {
            // Positive odds
            const oddsValue = parseInt(odds.substring(1));
            return stake * (oddsValue / 100) + stake;
        } else if (odds.startsWith('-')) {
            // Negative odds
            const oddsValue = parseInt(odds.substring(1));
            return stake * (100 / oddsValue) + stake;
        }
        return stake;
    }
    
    updateAverageOdds() {
        const settledBets = this.betHistory.filter(bet => bet.result !== 'pending');
        if (settledBets.length === 0) return;
        
        const totalOdds = settledBets.reduce((sum, bet) => {
            const oddsValue = this.convertOddsToDecimal(bet.odds);
            return sum + oddsValue;
        }, 0);
        
        this.portfolio.averageOdds = totalOdds / settledBets.length;
    }
    
    convertOddsToDecimal(odds) {
        if (odds.startsWith('+')) {
            return (parseInt(odds.substring(1)) / 100) + 1;
        } else if (odds.startsWith('-')) {
            return (100 / parseInt(odds.substring(1))) + 1;
        }
        return 1;
    }
    
    // Achievement System
    checkBettingAchievements(bet) {
        const achievements = CONFIG.PAPER_TRADING.achievements;
        
        // First Win
        if (bet.result === 'win' && !achievements.first_win.unlocked) {
            this.unlockAchievement('first_win');
        }
        
        // Win Streak
        if (this.portfolio.currentStreak >= 5 && !achievements.win_streak_5.unlocked) {
            this.unlockAchievement('win_streak_5');
        }
        
        // Profit milestones
        if (this.portfolio.totalProfit >= 1000 && !achievements.profit_1000.unlocked) {
            this.unlockAchievement('profit_1000');
        }
        
        // ROI milestones
        const roi = (this.portfolio.totalProfit / CONFIG.PAPER_TRADING.starting_balance) * 100;
        if (roi >= 10 && !achievements.roi_10_percent.unlocked) {
            this.unlockAchievement('roi_10_percent');
        }
        
        // Perfect parlay (if applicable)
        if (bet.type === 'parlay' && bet.result === 'win') {
            // Check if it was a 5+ leg parlay
            if (bet.legs >= 5 && !achievements.perfect_parlay.unlocked) {
                this.unlockAchievement('perfect_parlay');
            }
        }
    }
    
    unlockAchievement(achievementKey) {
        const achievement = CONFIG.PAPER_TRADING.achievements[achievementKey];
        if (!achievement) return;
        
        const unlockedAchievement = {
            ...achievement,
            date: new Date().toISOString(),
            unlocked: true
        };
        
        this.achievements.push(unlockedAchievement);
        
        // Add reward to balance
        this.portfolio.balance += achievement.reward;
        
        // Play achievement sound
        this.audioManager.playAchievementSound('gold');
        
        // Show notification
        this.showNotification(
            `Achievement Unlocked: ${achievement.name}! +$${achievement.reward}`, 
            'success'
        );
        
        // Save data
        this.savePortfolioData();
        this.updateDashboard();
    }
    
    // Utility Functions
    filterBetsTable(filter) {
        // Implementation for filtering bets table
        console.log(`Filtering bets by: ${filter}`);
    }
    
    cashOutBet(betId) {
        // Implementation for cashing out early
        console.log(`Cashing out bet: ${betId}`);
    }
    
    viewBetDetails(betId) {
        // Implementation for viewing detailed bet information
        console.log(`Viewing details for bet: ${betId}`);
    }
    
    exportPortfolio() {
        const data = {
            portfolio: this.portfolio,
            betHistory: this.betHistory,
            activeBets: this.activeBets,
            achievements: this.achievements,
            exportDate: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `paper-trading-portfolio-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
        
        this.showNotification('Portfolio exported successfully!', 'success');
    }
    
    showNotification(message, type = 'info') {
        // Create and show notification
        const notification = document.createElement('div');
        notification.className = `fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 transform translate-x-full`;
        
        switch (type) {
            case 'success':
                notification.classList.add('bg-neon', 'text-midnight');
                break;
            case 'error':
                notification.classList.add('bg-coral', 'text-white');
                break;
            default:
                notification.classList.add('bg-electric', 'text-midnight');
        }
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.remove('translate-x-full'), 100);
        setTimeout(() => {
            notification.classList.add('translate-x-full');
            setTimeout(() => document.body.removeChild(notification), 300);
        }, 3000);
    }
    
    startRealTimeUpdates() {
        // Update dashboard every 30 seconds
        setInterval(() => {
            this.updateDashboard();
        }, 30000);
        
        // Simulate live bet updates
        setInterval(() => {
            this.updateLiveBets();
        }, 15000);
    }
    
    updateLiveBets() {
        // Simulate real-time updates to live bets
        this.activeBets.forEach(bet => {
            if (bet.result === 'pending' && Math.random() < 0.01) { // 1% chance per update
                const result = Math.random() < 0.55 ? 'win' : 'loss'; // 55% win rate for simulation
                this.settleBet(bet.id, result);
            }
        });
    }
    
    openBetModal() {
        // Implementation for opening bet placement modal
        console.log('Opening bet modal');
    }
    
    filterBets(filter) {
        // Implementation for filtering bets view
        console.log(`Filtering bets: ${filter}`);
    }
    
    showAchievements() {
        // Implementation for showing achievements modal
        console.log('Showing achievements');
    }
}

// Analysis Tools Classes
class KellyCalculator {
    render() {
        return `
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Probability of Winning (%)</label>
                    <input type="number" id="kellyProbability" class="w-full bg-charcoal border border-gray-600 rounded-lg px-4 py-3 text-white" placeholder="e.g., 55" min="0" max="100">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Decimal Odds</label>
                    <input type="number" id="kellyOdds" class="w-full bg-charcoal border border-gray-600 rounded-lg px-4 py-3 text-white" placeholder="e.g., 1.91" min="1" step="0.01">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Current Bankroll</label>
                    <input type="number" id="kellyBankroll" class="w-full bg-charcoal border border-gray-600 rounded-lg px-4 py-3 text-white" placeholder="e.g., 10000" min="0">
                </div>
                <button onclick="paperTradingDashboard.analysisTools.kelly.calculate()" class="w-full bg-gradient-to-r from-electric to-neon text-midnight py-3 rounded-lg font-bold">
                    Calculate Kelly Criterion
                </button>
                <div id="kellyResult" class="p-4 bg-charcoal rounded-lg hidden">
                    <h4 class="font-bold text-lg mb-2 text-electric">Recommended Bet Size:</h4>
                    <div class="text-2xl font-mono font-bold text-neon" id="kellyRecommendation"></div>
                    <div class="text-sm text-steel mt-2" id="kellyExplanation"></div>
                </div>
            </div>
        `;
    }
    
    calculate() {
        const probability = parseFloat(document.getElementById('kellyProbability').value) / 100;
        const odds = parseFloat(document.getElementById('kellyOdds').value);
        const bankroll = parseFloat(document.getElementById('kellyBankroll').value);
        
        if (!probability || !odds || !bankroll) {
            alert('Please fill in all fields');
            return;
        }
        
        const kellyFraction = (probability * odds - 1) / (odds - 1);
        const recommendedBet = Math.max(0, kellyFraction * bankroll);
        
        document.getElementById('kellyRecommendation').textContent = `$${recommendedBet.toFixed(2)}`;
        document.getElementById('kellyExplanation').textContent = 
            `This represents ${(kellyFraction * 100).toFixed(1)}% of your bankroll. ` +
            `The Kelly Criterion suggests betting this amount to maximize long-term growth.`;
        
        document.getElementById('kellyResult').classList.remove('hidden');
    }
}

class ValueBetFinder {
    render() {
        return `
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Your Estimated Probability (%)</label>
                    <input type="number" id="valueProbability" class="w-full bg-charcoal border border-gray-600 rounded-lg px-4 py-3 text-white" placeholder="e.g., 60" min="0" max="100">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Available Odds</label>
                    <input type="text" id="valueOdds" class="w-full bg-charcoal border border-gray-600 rounded-lg px-4 py-3 text-white" placeholder="e.g., +150 or -110">
                </div>
                <button onclick="paperTradingDashboard.analysisTools.value.calculate()" class="w-full bg-gradient-to-r from-electric to-neon text-midnight py-3 rounded-lg font-bold">
                    Find Value
                </button>
                <div id="valueResult" class="p-4 bg-charcoal rounded-lg hidden">
                    <h4 class="font-bold text-lg mb-2 text-neon">Value Analysis:</h4>
                    <div id="valueAnalysis"></div>
                </div>
            </div>
        `;
    }
    
    calculate() {
        const probability = parseFloat(document.getElementById('valueProbability').value) / 100;
        const oddsInput = document.getElementById('valueOdds').value;
        
        if (!probability || !oddsInput) {
            alert('Please fill in all fields');
            return;
        }
        
        const decimalOdds = this.convertOddsToDecimal(oddsInput);
        const expectedValue = (probability * decimalOdds) - 1;
        const impliedProbability = 1 / decimalOdds;
        
        let analysis = '';
        let hasValue = false;
        
        if (expectedValue > 0) {
            analysis = `✅ POSITIVE VALUE DETECTED!\n\n` +
                      `Expected Value: +${(expectedValue * 100).toFixed(2)}%\n` +
                      `Your probability: ${(probability * 100).toFixed(1)}%\n` +
                      `Implied probability: ${(impliedProbability * 100).toFixed(1)}%\n\n` +
                      `This bet has positive expected value and is worth considering.`;
            hasValue = true;
        } else {
            analysis = `❌ NO VALUE DETECTED\n\n` +
                      `Expected Value: ${(expectedValue * 100).toFixed(2)}%\n` +
                      `Your probability: ${(probability * 100).toFixed(1)}%\n` +
                      `Implied probability: ${(impliedProbability * 100).toFixed(1)}%\n\n` +
                      `The odds do not offer value based on your probability assessment.`;
        }
        
        document.getElementById('valueAnalysis').innerHTML = `
            <div class="whitespace-pre-line ${hasValue ? 'text-neon' : 'text-coral'}">${analysis}</div>
        `;
        
        document.getElementById('valueResult').classList.remove('hidden');
    }
    
    convertOddsToDecimal(odds) {
        if (odds.startsWith('+')) {
            return (parseInt(odds.substring(1)) / 100) + 1;
        } else if (odds.startsWith('-')) {
            return (100 / parseInt(odds.substring(1))) + 1;
        }
        return parseFloat(odds);
    }
}

class ArbitrageScanner {
    render() {
        return `
            <div class="space-y-4">
                <div class="p-4 bg-charcoal rounded-lg">
                    <h4 class="font-bold text-lg mb-2 text-amber">Arbitrage Opportunities</h4>
                    <p class="text-sm text-steel mb-4">Scan multiple sportsbooks for guaranteed profit opportunities.</p>
                    <div id="arbitrageResults">
                        <div class="text-center py-8 text-steel">
                            <div class="text-2xl mb-2">🔍</div>
                            <p>Scanning markets for arbitrage opportunities...</p>
                        </div>
                    </div>
                </div>
                <button onclick="paperTradingDashboard.analysisTools.arbitrage.scan()" class="w-full bg-amber text-midnight py-3 rounded-lg font-bold">
                    Scan Markets
                </button>
            </div>
        `;
    }
    
    scan() {
        const resultsElement = document.getElementById('arbitrageResults');
        
        // Simulate scanning for arbitrage opportunities
        setTimeout(() => {
            const opportunities = this.generateMockArbitrageOpportunities();
            
            if (opportunities.length === 0) {
                resultsElement.innerHTML = `
                    <div class="text-center py-8 text-steel">
                        <div class="text-2xl mb-2">❌</div>
                        <p>No arbitrage opportunities found at this time.</p>
                        <p class="text-xs mt-2">Check back later or adjust your scan parameters.</p>
                    </div>
                `;
            } else {
                resultsElement.innerHTML = opportunities.map(opp => `
                    <div class="p-3 bg-green-500 bg-opacity-20 border border-green-500 rounded-lg mb-3">
                        <div class="flex justify-between items-center mb-2">
                            <div class="font-bold text-green-400">${opp.game}</div>
                            <div class="font-mono text-green-400">${opp.profit}%</div>
                        </div>
                        <div class="text-sm text-steel">
                            ${opp.bookmaker1}: ${opp.odds1} vs ${opp.bookmaker2}: ${opp.odds2}
                        </div>
                        <div class="text-xs text-steel mt-1">
                            Guaranteed profit: $${opp.guaranteedProfit} per $100 staked
                        </div>
                    </div>
                `).join('');
            }
        }, 2000);
    }
    
    generateMockArbitrageOpportunities() {
        // Mock arbitrage opportunities for demonstration
        const opportunities = [];
        
        if (Math.random() < 0.3) { // 30% chance of finding opportunities
            opportunities.push({
                game: 'Kansas City Chiefs vs Buffalo Bills',
                bookmaker1: 'DraftKings',
                odds1: '+150',
                bookmaker2: 'FanDuel',
                odds2: '-140',
                profit: 2.1,
                guaranteedProfit: 2.10
            });
        }
        
        return opportunities;
    }
}

class BankrollManager {
    render() {
        return `
            <div class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="p-4 bg-charcoal rounded-lg">
                        <h4 class="font-bold text-lg mb-2 text-electric">Current Bankroll</h4>
                        <div class="text-2xl font-mono font-bold text-neon" id="currentBankrollDisplay">$10,000</div>
                    </div>
                    <div class="p-4 bg-charcoal rounded-lg">
                        <h4 class="font-bold text-lg mb-2 text-amber">Recommended Bet Sizes</h4>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between">
                                <span>Conservative (1%):</span>
                                <span class="font-mono" id="conservativeBet">$100</span>
                            </div>
                            <div class="flex justify-between">
                                <span>Moderate (2%):</span>
                                <span class="font-mono" id="moderateBet">$200</span>
                            </div>
                            <div class="flex justify-between">
                                <span>Aggressive (5%):</span>
                                <span class="font-mono" id="aggressiveBet">$500</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="space-y-4">
                    <h4 class="font-bold text-lg text-coral">Bankroll Management Rules</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="p-4 bg-charcoal rounded-lg">
                            <h5 class="font-bold mb-2 text-electric">Flat Betting</h5>
                            <p class="text-sm text-steel mb-2">Bet the same amount on every game regardless of confidence.</p>
                            <div class="text-xs text-steel">Recommended: 1-3% of bankroll per bet</div>
                        </div>
                        <div class="p-4 bg-charcoal rounded-lg">
                            <h5 class="font-bold mb-2 text-neon">Percentage Betting</h5>
                            <p class="text-sm text-steel mb-2">Bet a fixed percentage of your current bankroll.</p>
                            <div class="text-xs text-steel">Adjusts automatically as bankroll changes</div>
                        </div>
                        <div class="p-4 bg-charcoal rounded-lg">
                            <h5 class="font-bold mb-2 text-amber">Kelly Criterion</h5>
                            <p class="text-sm text-steel mb-2">Bet based on your edge and the odds offered.</p>
                            <div class="text-xs text-steel">Mathematically optimal for long-term growth</div>
                        </div>
                        <div class="p-4 bg-charcoal rounded-lg">
                            <h5 class="font-bold mb-2 text-coral">Confidence-Based</h5>
                            <p class="text-sm text-steel mb-2">Vary bet size based on your confidence level.</p>
                            <div class="text-xs text-steel">Scale bets from 0.5% to 5% based on confidence</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.paperTradingDashboard = new PaperTradingDashboard();
});