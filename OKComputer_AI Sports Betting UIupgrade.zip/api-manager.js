// SportsPredict AI - API Manager
// Handles all live sports data, scores, odds, and streaming

class APIManager {
    constructor() {
        this.apiKeys = {
            primary: CONFIG.API.PRIMARY_API_KEY,
            odds: CONFIG.API.ODDS_API_KEY,
            backup: CONFIG.API.BACKUP_API_KEY
        };
        
        this.rateLimits = new Map();
        this.cache = new Map();
        this.isLiveMode = !CONFIG.DEV.mock_data;
        
        this.init();
    }
    
    init() {
        this.setupRateLimiting();
        this.initializeWebSockets();
        this.startDataSync();
    }
    
    setupRateLimiting() {
        // Track API calls to prevent rate limit violations
        setInterval(() => {
            this.rateLimits.clear();
        }, CONFIG.API.RATE_LIMIT_WINDOW);
    }
    
    checkRateLimit(apiType) {
        const current = this.rateLimits.get(apiType) || 0;
        if (current >= CONFIG.API.RATE_LIMIT) {
            console.warn(`Rate limit exceeded for ${apiType}`);
            return false;
        }
        this.rateLimits.set(apiType, current + 1);
        return true;
    }
    
    async makeAPICall(url, options = {}, apiType = 'primary') {
        if (!this.checkRateLimit(apiType)) {
            return this.getMockData(url);
        }
        
        try {
            const response = await fetch(url, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            this.cache.set(url, { data, timestamp: Date.now() });
            return data;
            
        } catch (error) {
            console.error(`API call failed: ${error.message}`);
            return this.getMockData(url);
        }
    }
    
    getMockData(endpoint) {
        // Return realistic mock data when APIs are unavailable
        const mockData = {
            '/fixtures': {
                response: [
                    {
                        fixture: {
                            id: 1035227,
                            date: '2025-01-15T18:00:00+00:00',
                            status: { long: 'Not Started', short: 'NS' }
                        },
                        teams: {
                            home: { name: 'Kansas City Chiefs', logo: 'https://media.api-sports.io/american-football/teams/1.png' },
                            away: { name: 'Buffalo Bills', logo: 'https://media.api-sports.io/american-football/teams/2.png' }
                        },
                        odds: [
                            {
                                name: 'Match Winner',
                                values: [
                                    { odd: '1.65', value: 'Home' },
                                    { odd: '2.20', value: 'Away' }
                                ]
                            }
                        ]
                    }
                ]
            },
            '/odds': {
                home_odds: -150,
                away_odds: +130,
                over_under: 51.5,
                spread: -3.5
            },
            '/livescores': {
                games: [
                    {
                        id: 1035227,
                        home_score: 14,
                        away_score: 10,
                        time: '2nd Quarter - 8:45',
                        status: 'live'
                    }
                ]
            }
        };
        
        // Find matching mock data
        for (const [key, data] of Object.entries(mockData)) {
            if (endpoint.includes(key.replace('/', ''))) {
                return data;
            }
        }
        
        return mockData['/fixtures'];
    }
    
    // Live Scores API
    async getLiveScores(sport = 'americanfootball', date = null) {
        if (!this.isLiveMode) {
            return this.getMockData('/livescores');
        }
        
        const targetDate = date || new Date().toISOString().split('T')[0];
        const url = `${CONFIG.API.PRIMARY_BASE_URL}/fixtures?date=${targetDate}&sport=${sport}`;
        
        return await this.makeAPICall(url, {
            headers: {
                'x-apisports-key': this.apiKeys.primary
            }
        }, 'scores');
    }
    
    // Odds API
    async getOdds(gameId, market = 'h2h') {
        if (!this.isLiveMode) {
            return this.getMockData('/odds');
        }
        
        const url = `${CONFIG.API.ODDS_BASE_URL}/events/${gameId}/odds?market=${market}`;
        
        return await this.makeAPICall(url, {
            headers: {
                'Authorization': `Bearer ${this.apiKeys.odds}`
            }
        }, 'odds');
    }
    
    // Team Statistics API
    async getTeamStats(teamId, season = '2024') {
        if (!this.isLiveMode) {
            return this.generateMockTeamStats(teamId);
        }
        
        const url = `${CONFIG.API.PRIMARY_BASE_URL}/teams/statistics?team=${teamId}&season=${season}`;
        
        return await this.makeAPICall(url, {
            headers: {
                'x-apisports-key': this.apiKeys.primary
            }
        }, 'stats');
    }
    
    // Player Statistics API
    async getPlayerStats(playerId, season = '2024') {
        if (!this.isLiveMode) {
            return this.generateMockPlayerStats(playerId);
        }
        
        const url = `${CONFIG.API.PRIMARY_BASE_URL}/players/statistics?player=${playerId}&season=${season}`;
        
        return await this.makeAPICall(url, {
            headers: {
                'x-apisports-key': this.apiKeys.primary
            }
        }, 'stats');
    }
    
    // Injuries API
    async getInjuries(sport = 'americanfootball', date = null) {
        if (!this.isLiveMode) {
            return this.generateMockInjuries();
        }
        
        const targetDate = date || new Date().toISOString().split('T')[0];
        const url = `${CONFIG.API.BACKUP_BASE_URL}/injuries/${sport}/${targetDate}?key=${this.apiKeys.backup}`;
        
        return await this.makeAPICall(url, {}, 'injuries');
    }
    
    // Weather API
    async getWeatherForecast(gameId) {
        // Integration with weather API would go here
        return this.generateMockWeather(gameId);
    }
    
    // Streaming API
    async getStreamingUrl(gameId, provider = 'twitch') {
        if (!CONFIG.STREAMING.enabled) {
            return null;
        }
        
        // In production, this would connect to streaming providers
        const streamingUrls = {
            twitch: `${CONFIG.STREAMING.providers.twitch}?channel=nfl_live_${gameId}`,
            youtube: `${CONFIG.STREAMING.providers.youtube}?v=game_${gameId}`,
            custom: `${CONFIG.STREAMING.providers.custom}stream/${gameId}`
        };
        
        return streamingUrls[provider] || streamingUrls.custom;
    }
    
    // WebSocket for real-time updates
    initializeWebSockets() {
        if (!this.isLiveMode) return;
        
        // In production, connect to real WebSocket endpoints
        this.websockets = {
            scores: null,
            odds: null,
            injuries: null
        };
        
        // Simulate WebSocket updates
        this.simulateRealTimeUpdates();
    }
    
    simulateRealTimeUpdates() {
        setInterval(() => {
            this.broadcastUpdate('scores', this.generateLiveScoreUpdate());
        }, CONFIG.API.SCORES_UPDATE_INTERVAL);
        
        setInterval(() => {
            this.broadcastUpdate('odds', this.generateOddsUpdate());
        }, CONFIG.API.ODDS_UPDATE_INTERVAL);
    }
    
    broadcastUpdate(type, data) {
        const event = new CustomEvent(`api-update-${type}`, { detail: data });
        document.dispatchEvent(event);
    }
    
    generateLiveScoreUpdate() {
        return {
            gameId: Math.floor(Math.random() * 1000000),
            homeScore: Math.floor(Math.random() * 35),
            awayScore: Math.floor(Math.random() * 35),
            time: `${Math.floor(Math.random() * 4) + 1}Q ${Math.floor(Math.random() * 15)}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
            status: 'live'
        };
    }
    
    generateOddsUpdate() {
        const baseOdds = -150;
        const variation = Math.floor(Math.random() * 20) - 10;
        return {
            gameId: Math.floor(Math.random() * 1000000),
            homeOdds: baseOdds + variation,
            awayOdds: 130 - variation,
            total: 51.5 + (Math.random() * 2 - 1),
            spread: -3.5 + (Math.random() * 0.5 - 0.25)
        };
    }
    
    // Mock data generators
    generateMockTeamStats(teamId) {
        return {
            team: { id: teamId, name: `Team ${teamId}` },
            statistics: {
                wins: Math.floor(Math.random() * 16) + 1,
                losses: Math.floor(Math.random() * 16),
                points_for: Math.floor(Math.random() * 500) + 300,
                points_against: Math.floor(Math.random() * 400) + 250,
                yards_per_game: Math.floor(Math.random() * 200) + 300,
                turnovers: Math.floor(Math.random() * 30),
                sacks: Math.floor(Math.random() * 50)
            }
        };
    }
    
    generateMockPlayerStats(playerId) {
        return {
            player: { id: playerId, name: `Player ${playerId}` },
            statistics: {
                games_played: Math.floor(Math.random() * 16) + 1,
                passing_yards: Math.floor(Math.random() * 4000) + 1000,
                touchdowns: Math.floor(Math.random() * 40) + 5,
                interceptions: Math.floor(Math.random() * 15),
                rating: (Math.random() * 50 + 70).toFixed(1)
            }
        };
    }
    
    generateMockInjuries() {
        return {
            injuries: [
                {
                    player: 'Patrick Mahomes',
                    team: 'Kansas City Chiefs',
                    injury: 'Ankle',
                    status: 'Questionable',
                    date: new Date().toISOString().split('T')[0]
                },
                {
                    player: 'Josh Allen',
                    team: 'Buffalo Bills',
                    injury: 'Shoulder',
                    status: 'Probable',
                    date: new Date().toISOString().split('T')[0]
                }
            ]
        };
    }
    
    generateMockWeather(gameId) {
        return {
            temperature: Math.floor(Math.random() * 40) + 30,
            condition: ['Clear', 'Cloudy', 'Rain', 'Snow'][Math.floor(Math.random() * 4)],
            wind_speed: Math.floor(Math.random() * 20) + 5,
            humidity: Math.floor(Math.random() * 40) + 40,
            visibility: 'Good',
            precipitation: Math.floor(Math.random() * 100)
        };
    }
    
    // Data sync for offline support
    startDataSync() {
        // Sync data to localStorage for offline access
        setInterval(() => {
            this.syncDataToCache();
        }, 60000); // Sync every minute
    }
    
    syncDataToCache() {
        const data = {
            scores: this.cache.get('latest_scores'),
            odds: this.cache.get('latest_odds'),
            injuries: this.cache.get('latest_injuries'),
            timestamp: Date.now()
        };
        
        localStorage.setItem('sports_data_cache', JSON.stringify(data));
    }
    
    loadCachedData() {
        const cached = localStorage.getItem('sports_data_cache');
        if (cached) {
            const data = JSON.parse(cached);
            // Check if cache is less than 1 hour old
            if (Date.now() - data.timestamp < 3600000) {
                return data;
            }
        }
        return null;
    }
    
    // Error handling
    handleAPIError(error, apiType) {
        console.error(`${apiType} API error:`, error);
        
        // Fallback to mock data on error
        return this.getMockData(`/${apiType}`);
    }
    
    // Health check
    async checkAPIHealth() {
        const health = {
            primary: false,
            odds: false,
            backup: false,
            timestamp: Date.now()
        };
        
        try {
            // Test primary API
            const primaryTest = await this.makeAPICall(
                `${CONFIG.API.PRIMARY_BASE_URL}/status`,
                { headers: { 'x-apisports-key': this.apiKeys.primary } }
            );
            health.primary = !!primaryTest;
        } catch (e) {
            health.primary = false;
        }
        
        return health;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = APIManager;
}

// Make available globally
window.APIManager = APIManager;