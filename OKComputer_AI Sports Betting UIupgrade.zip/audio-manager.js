// SportsPredict AI - Audio Manager
// Handles all sound effects, team anthems, and audio notifications

class AudioManager {
    constructor() {
        this.audioContext = null;
        this.sounds = new Map();
        this.currentMusic = null;
        this.masterVolume = CONFIG.AUDIO.volume;
        this.enabled = CONFIG.AUDIO.enabled;
        
        this.init();
    }
    
    init() {
        this.setupAudioContext();
        this.preloadSounds();
        this.setupEventListeners();
    }
    
    setupAudioContext() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        } catch (error) {
            console.warn('Web Audio API not supported:', error);
        }
    }
    
    async preloadSounds() {
        // Preload all sound effects to reduce latency
        const soundPacks = CONFIG.AUDIO.sound_packs;
        
        for (const [sport, sounds] of Object.entries(soundPacks)) {
            for (const [event, url] of Object.entries(sounds)) {
                try {
                    const audio = new Audio();
                    audio.src = url;
                    audio.preload = 'auto';
                    audio.volume = this.masterVolume;
                    
                    // Create multiple instances for overlapping sounds
                    this.sounds.set(`${sport}_${event}`, [
                        audio,
                        audio.cloneNode(),
                        audio.cloneNode()
                    ]);
                } catch (error) {
                    console.warn(`Failed to preload sound ${sport}_${event}:`, error);
                }
            }
        }
        
        // Preload UI sounds
        await this.preloadUISounds();
    }
    
    async preloadUISounds() {
        const uiSounds = {
            click: 'resources/audio/ui/click.mp3',
            hover: 'resources/audio/ui/hover.mp3',
            success: 'resources/audio/ui/success.mp3',
            error: 'resources/audio/ui/error.mp3',
            notification: 'resources/audio/ui/notification.mp3',
            bet_placed: 'resources/audio/ui/bet_placed.mp3',
            win: 'resources/audio/ui/win.mp3',
            loss: 'resources/audio/ui/loss.mp3'
        };
        
        for (const [event, url] of Object.entries(uiSounds)) {
            try {
                const audio = new Audio();
                audio.src = url;
                audio.preload = 'auto';
                audio.volume = this.masterVolume * 0.5; // UI sounds quieter
                
                this.sounds.set(`ui_${event}`, [audio]);
            } catch (error) {
                console.warn(`Failed to preload UI sound ${event}:`, error);
            }
        }
    }
    
    setupEventListeners() {
        // Listen for sports events
        document.addEventListener('sports-event', (event) => {
            this.handleSportsEvent(event.detail);
        });
        
        // Listen for UI events
        document.addEventListener('ui-event', (event) => {
            this.handleUIEvent(event.detail);
        });
        
        // Listen for betting events
        document.addEventListener('betting-event', (event) => {
            this.handleBettingEvent(event.detail);
        });
        
        // Handle user interactions
        this.setupInteractionSounds();
    }
    
    setupInteractionSounds() {
        // Add click sounds to buttons
        document.addEventListener('click', (event) => {
            if (event.target.matches('button, .clickable, .nav-link')) {
                this.playUISound('click');
            }
        });
        
        // Add hover sounds to interactive elements
        document.addEventListener('mouseover', (event) => {
            if (event.target.matches('.hoverable, .prediction-card, .nav-link')) {
                this.playUISound('hover');
            }
        });
    }
    
    // Sound Effect Management
    playSound(sport, event, volume = 1.0) {
        if (!this.enabled) return;
        
        const soundKey = `${sport}_${event}`;
        const soundPool = this.sounds.get(soundKey);
        
        if (!soundPool || soundPool.length === 0) {
            console.warn(`Sound not found: ${soundKey}`);
            return;
        }
        
        // Find an available sound instance
        const audio = soundPool.find(sound => sound.paused || sound.ended) || soundPool[0];
        
        // Clone if still playing
        if (!audio.paused && !audio.ended) {
            const clone = audio.cloneNode();
            clone.volume = this.masterVolume * volume;
            clone.play().catch(error => console.warn('Audio play failed:', error));
        } else {
            audio.volume = this.masterVolume * volume;
            audio.play().catch(error => console.warn('Audio play failed:', error));
        }
    }
    
    playUISound(event, volume = 1.0) {
        if (!this.enabled) return;
        
        const soundKey = `ui_${event}`;
        const soundPool = this.sounds.get(soundKey);
        
        if (!soundPool || soundPool.length === 0) {
            return; // UI sounds are optional
        }
        
        const audio = soundPool[0];
        audio.volume = this.masterVolume * volume * 0.5; // UI sounds are quieter
        audio.play().catch(error => console.warn('UI audio play failed:', error));
    }
    
    // Sports Event Handlers
    handleSportsEvent(eventData) {
        const { sport, event, team, importance = 'normal' } = eventData;
        
        switch (event) {
            case 'touchdown':
                this.playSound(sport, 'touchdown', importance === 'critical' ? 1.5 : 1.0);
                this.playSound(sport, 'crowd_cheer', 0.8);
                break;
                
            case 'field_goal':
                this.playSound(sport, 'field_goal', importance === 'critical' ? 1.3 : 1.0);
                break;
                
            case 'basket':
                if (importance === 'critical') {
                    this.playSound(sport, 'buzzer_beater', 1.5);
                } else {
                    this.playSound(sport, 'three_pointer', 1.0);
                }
                break;
                
            case 'goal':
                this.playSound(sport, 'goal', importance === 'critical' ? 1.5 : 1.2);
                this.playSound(sport, 'crowd_cheer', 0.8);
                break;
                
            case 'home_run':
                this.playSound(sport, 'home_run', 1.3);
                this.playSound(sport, 'crowd_cheer', 0.9);
                break;
                
            case 'penalty':
                this.playSound(sport, 'penalty', 1.0);
                this.playSound(sport, 'whistle', 0.7);
                break;
                
            case 'game_end':
                this.playSound(sport, 'whistle', 1.0);
                break;
                
            default:
                console.log(`Unhandled sports event: ${event}`);
        }
    }
    
    // UI Event Handlers
    handleUIEvent(eventData) {
        const { event, importance = 'normal' } = eventData;
        
        switch (event) {
            case 'page_load':
                this.playUISound('success', 0.5);
                break;
                
            case 'navigation':
                this.playUISound('click', 0.3);
                break;
                
            case 'modal_open':
                this.playUISound('click', 0.4);
                break;
                
            case 'modal_close':
                this.playUISound('click', 0.3);
                break;
                
            case 'success':
                this.playUISound('success', importance === 'high' ? 1.0 : 0.7);
                break;
                
            case 'error':
                this.playUISound('error', 0.8);
                break;
                
            case 'notification':
                this.playUISound('notification', 0.6);
                break;
                
            default:
                console.log(`Unhandled UI event: ${event}`);
        }
    }
    
    // Betting Event Handlers
    handleBettingEvent(eventData) {
        const { event, amount, odds, result } = eventData;
        
        switch (event) {
            case 'bet_placed':
                this.playUISound('bet_placed', 0.7);
                break;
                
            case 'bet_won':
                this.playUISound('win', 1.2);
                // Add crowd cheer for big wins
                if (amount > 100) {
                    setTimeout(() => this.playUISound('crowd_cheer', 0.5), 500);
                }
                break;
                
            case 'bet_lost':
                this.playUISound('loss', 0.8);
                break;
                
            case 'parlay_won':
                this.playUISound('win', 1.5);
                this.playUISound('crowd_cheer', 0.8);
                break;
                
            case 'jackpot':
                this.playUISound('win', 2.0);
                setTimeout(() => this.playUISound('crowd_cheer', 1.0), 300);
                setTimeout(() => this.playUISound('success', 1.0), 600);
                break;
                
            default:
                console.log(`Unhandled betting event: ${event}`);
        }
    }
    
    // Background Music Management
    playBackgroundMusic(sport = 'general') {
        if (!this.enabled || this.currentMusic) return;
        
        const musicTracks = {
            football: 'resources/audio/music/football_ambient.mp3',
            basketball: 'resources/audio/music/basketball_ambient.mp3',
            baseball: 'resources/audio/music/baseball_ambient.mp3',
            general: 'resources/audio/music/general_ambient.mp3'
        };
        
        const track = musicTracks[sport] || musicTracks.general;
        
        this.currentMusic = new Audio();
        this.currentMusic.src = track;
        this.currentMusic.loop = true;
        this.currentMusic.volume = this.masterVolume * 0.3; // Music is quieter
        
        this.currentMusic.play().catch(error => {
            console.warn('Background music play failed:', error);
        });
    }
    
    stopBackgroundMusic() {
        if (this.currentMusic) {
            this.currentMusic.pause();
            this.currentMusic = null;
        }
    }
    
    fadeOutMusic(duration = 2000) {
        if (!this.currentMusic) return;
        
        const fadeInterval = setInterval(() => {
            if (this.currentMusic.volume > 0.1) {
                this.currentMusic.volume -= 0.1;
            } else {
                clearInterval(fadeInterval);
                this.stopBackgroundMusic();
            }
        }, duration / 20);
    }
    
    // Volume Control
    setMasterVolume(volume) {
        this.masterVolume = Math.max(0, Math.min(1, volume));
        
        // Update all playing sounds
        this.sounds.forEach(soundPool => {
            soundPool.forEach(audio => {
                if (!audio.paused) {
                    audio.volume = this.masterVolume;
                }
            });
        });
        
        if (this.currentMusic) {
            this.currentMusic.volume = this.masterVolume * 0.3;
        }
    }
    
    toggleMute() {
        this.enabled = !this.enabled;
        
        if (!this.enabled) {
            this.stopAllSounds();
            this.stopBackgroundMusic();
        }
        
        return this.enabled;
    }
    
    stopAllSounds() {
        this.sounds.forEach(soundPool => {
            soundPool.forEach(audio => {
                if (!audio.paused) {
                    audio.pause();
                    audio.currentTime = 0;
                }
            });
        });
    }
    
    // Advanced Audio Effects
    playSoundWithDelay(sport, event, delay, volume = 1.0) {
        setTimeout(() => {
            this.playSound(sport, event, volume);
        }, delay);
    }
    
    playSequentialSounds(sounds) {
        // sounds = [{sport, event, delay, volume}, ...]
        sounds.forEach(sound => {
            this.playSoundWithDelay(
                sound.sport,
                sound.event,
                sound.delay,
                sound.volume
            );
        });
    }
    
    // Spatial Audio (for future 3D enhancements)
    createSpatialAudio(x, y, z) {
        if (!this.audioContext) return null;
        
        const panner = this.audioContext.createPanner();
        panner.positionX.setValueAtTime(x, this.audioContext.currentTime);
        panner.positionY.setValueAtTime(y, this.audioContext.currentTime);
        panner.positionZ.setValueAtTime(z, this.audioContext.currentTime);
        
        return panner;
    }
    
    // Audio Analysis (for visualizations)
    createAnalyzer() {
        if (!this.audioContext) return null;
        
        const analyzer = this.audioContext.createAnalyser();
        analyzer.fftSize = 256;
        return analyzer;
    }
    
    getFrequencyData(analyzer) {
        if (!analyzer) return null;
        
        const bufferLength = analyzer.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyzer.getByteFrequencyData(dataArray);
        
        return dataArray;
    }
    
    // Notification Sounds
    playNotificationSound(type = 'default') {
        const notifications = {
            default: 'notification',
            success: 'success',
            error: 'error',
            warning: 'error',
            info: 'notification'
        };
        
        const sound = notifications[type] || notifications.default;
        this.playUISound(sound, 0.8);
    }
    
    // Achievement Sounds
    playAchievementSound(achievementLevel = 'bronze') {
        const achievements = {
            bronze: [{ sport: 'ui', event: 'success', delay: 0, volume: 1.0 }],
            silver: [
                { sport: 'ui', event: 'success', delay: 0, volume: 1.0 },
                { sport: 'ui', event: 'success', delay: 200, volume: 0.8 }
            ],
            gold: [
                { sport: 'ui', event: 'success', delay: 0, volume: 1.2 },
                { sport: 'ui', event: 'success', delay: 150, volume: 1.0 },
                { sport: 'ui', event: 'success', delay: 300, volume: 0.8 }
            ],
            platinum: [
                { sport: 'ui', event: 'success', delay: 0, volume: 1.5 },
                { sport: 'ui', event: 'success', delay: 100, volume: 1.2 },
                { sport: 'ui', event: 'success', delay: 200, volume: 1.0 },
                { sport: 'ui', event: 'success', delay: 300, volume: 0.8 }
            ]
        };
        
        const soundSequence = achievements[achievementLevel] || achievements.bronze;
        this.playSequentialSounds(soundSequence);
    }
    
    // Preset Sound Combinations
    playGameStartSequence(sport) {
        const sequence = [
            { sport: 'ui', event: 'success', delay: 0, volume: 0.5 },
            { sport: sport, event: 'whistle', delay: 500, volume: 0.7 },
            { sport: sport, event: 'crowd_cheer', delay: 1000, volume: 0.3 }
        ];
        
        this.playSequentialSounds(sequence);
    }
    
    playGameEndSequence(sport, winner = 'home') {
        const sequence = [
            { sport: sport, event: 'whistle', delay: 0, volume: 1.0 },
            { sport: sport, event: 'crowd_cheer', delay: 500, volume: 0.8 },
            { sport: 'ui', event: 'success', delay: 1000, volume: 0.6 }
        ];
        
        this.playSequentialSounds(sequence);
    }
    
    playBigWinSequence() {
        const sequence = [
            { sport: 'ui', event: 'win', delay: 0, volume: 1.5 },
            { sport: 'ui', event: 'crowd_cheer', delay: 300, volume: 1.0 },
            { sport: 'ui', event: 'success', delay: 600, volume: 1.2 },
            { sport: 'ui', event: 'crowd_cheer', delay: 900, volume: 0.8 }
        ];
        
        this.playSequentialSounds(sequence);
    }
    
    // Settings and Preferences
    getSettings() {
        return {
            enabled: this.enabled,
            masterVolume: this.masterVolume,
            musicEnabled: !!this.currentMusic,
            soundEffectsEnabled: this.enabled
        };
    }
    
    applySettings(settings) {
        if (settings.masterVolume !== undefined) {
            this.setMasterVolume(settings.masterVolume);
        }
        
        if (settings.enabled !== undefined) {
            this.enabled = settings.enabled;
            if (!this.enabled) {
                this.stopAllSounds();
                this.stopBackgroundMusic();
            }
        }
    }
    
    // Cleanup
    destroy() {
        this.stopAllSounds();
        this.stopBackgroundMusic();
        
        if (this.audioContext) {
            this.audioContext.close();
        }
        
        this.sounds.clear();
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AudioManager;
}

// Make available globally
window.AudioManager = AudioManager;