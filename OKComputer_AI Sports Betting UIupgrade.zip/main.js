// SportsPredict AI - Main JavaScript Application
// Professional Sports Betting Platform with AI Predictions

class SportsBettingApp {
    constructor() {
        this.currentPage = this.getCurrentPage();
        this.betSlip = [];
        this.paperTradingBalance = 10000;
        this.betHistory = [];
        this.achievements = [];
        
        this.init();
    }
    
    getCurrentPage() {
        const path = window.location.pathname;
        if (path.includes('analytics')) return 'analytics';
        if (path.includes('paper-trading')) return 'paper-trading';
        return 'dashboard';
    }
    
    init() {
        this.initializeCommonFeatures();
        
        switch(this.currentPage) {
            case 'dashboard':
                this.initializeDashboard();
                break;
            case 'analytics':
                this.initializeAnalytics();
                break;
            case 'paper-trading':
                this.initializePaperTrading();
                break;
        }
        
        this.startDataSimulation();
    }
    
    initializeCommonFeatures() {
        // Mobile menu toggle
        this.setupMobileMenu();
        
        // Smooth scrolling for anchor links
        this.setupSmoothScrolling();
        
        // Animate elements on scroll
        this.setupScrollAnimations();
    }
    
    setupMobileMenu() {
        // Mobile menu functionality would go here
        // For now, focusing on desktop experience
    }
    
    setupSmoothScrolling() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }
    
    setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observe elements with animation classes
        document.querySelectorAll('.animate-fade-in, .animate-float').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
    }
    
    // Dashboard Specific Features
    initializeDashboard() {
        this.generatePredictionCards();
        this.setupBetSlip();
        this.setupSportTabs();
        this.initializeValueBets();
        this.initializeLiveUpdates();
    }
    
    generatePredictionCards() {
        const gamesGrid = document.getElementById('gamesGrid');
        if (!gamesGrid) return;
        
        const games = this.getMockGames();
        
        gamesGrid.innerHTML = games.map(game => `
            <div class="prediction-card glass-morphism rounded-2xl p-6 hover:glow" data-game-id="${game.id}">
                <div class="flex justify-between items-start mb-4">
                    <div class="ai-badge">AI ${game.confidence}%</div>
                    <div class="text-sm text-steel">${game.time}</div>
                </div>
                
                <div class="mb-6">
                    <div class="flex justify-between items-center mb-3">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-gradient-to-r from-electric to-neon rounded-full flex items-center justify-center">
                                <span class="text-midnight font-bold text-xs">${game.homeTeam.abbreviation}</span>
                            </div>
                            <div>
                                <div class="font-bold">${game.homeTeam.name}</div>
                                <div class="text-sm text-steel">${game.homeTeam.record}</div>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="odds-display text-lg font-bold">${game.homeTeam.odds}</div>
                            <button class="text-xs text-electric hover:underline" onclick="addToBetSlip('${game.id}', 'home')">Add to Slip</button>
                        </div>
                    </div>
                    
                    <div class="flex justify-between items-center">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-gradient-to-r from-amber to-coral rounded-full flex items-center justify-center">
                                <span class="text-midnight font-bold text-xs">${game.awayTeam.abbreviation}</span>
                            </div>
                            <div>
                                <div class="font-bold">${game.awayTeam.name}</div>
                                <div class="text-sm text-steel">${game.awayTeam.record}</div>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="odds-display text-lg font-bold">${game.awayTeam.odds}</div>
                            <button class="text-xs text-electric hover:underline" onclick="addToBetSlip('${game.id}', 'away')">Add to Slip</button>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <div class="flex justify-between text-sm mb-2">
                        <span>AI Confidence</span>
                        <span>${game.confidence}%</span>
                    </div>
                    <div class="confidence-meter">
                        <div class="confidence-fill" style="width: ${game.confidence}%"></div>
                    </div>
                </div>
                
                <div class="text-center">
                    <div class="text-sm text-steel mb-2">AI Predicted Winner</div>
                    <div class="font-bold text-neon">${game.predictedWinner}</div>
                    <div class="text-sm text-steel">${game.predictedScore}</div>
                </div>
                
                <div class="mt-4 pt-4 border-t border-gray-700">
                    <div class="flex justify-between text-xs text-steel">
                        <span>Weather: ${game.weather}</span>
                        <span>Injuries: ${game.injuries}</span>
                    </div>
                </div>
            </div>
        `).join('');
        
        // Animate cards
        anime({
            targets: '.prediction-card',
            translateY: [50, 0],
            opacity: [0, 1],
            delay: anime.stagger(100),
            duration: 800,
            easing: 'easeOutExpo'
        });
    }
    
    getMockGames() {
        return [
            {
                id: 'nfl_kc_vs_buf',
                time: 'Today 8:15 PM',
                homeTeam: {
                    name: 'Kansas City Chiefs',
                    abbreviation: 'KC',
                    record: '12-4',
                    odds: '-3.5'
                },
                awayTeam: {
                    name: 'Buffalo Bills',
                    abbreviation: 'BUF',
                    record: '11-5',
                    odds: '+3.5'
                },
                confidence: 78,
                predictedWinner: 'Kansas City Chiefs',
                predictedScore: '28-24',
                weather: 'Clear 45°F',
                injuries: 'None Critical'
            },
            {
                id: 'nfl_lac_vs_den',
                time: 'Today 4:25 PM',
                homeTeam: {
                    name: 'LA Chargers',
                    abbreviation: 'LAC',
                    record: '9-7',
                    odds: '-6.5'
                },
                awayTeam: {
                    name: 'Denver Broncos',
                    abbreviation: 'DEN',
                    record: '8-8',
                    odds: '+6.5'
                },
                confidence: 65,
                predictedWinner: 'LA Chargers',
                predictedScore: '24-17',
                weather: 'Partly Cloudy',
                injuries: '2 Questionable'
            },
            {
                id: 'nfl_gb_vs_min',
                time: 'Tomorrow 1:00 PM',
                homeTeam: {
                    name: 'Green Bay Packers',
                    abbreviation: 'GB',
                    record: '10-6',
                    odds: '-2.5'
                },
                awayTeam: {
                    name: 'Minnesota Vikings',
                    abbreviation: 'MIN',
                    record: '7-9',
                    odds: '+2.5'
                },
                confidence: 72,
                predictedWinner: 'Green Bay Packers',
                predictedScore: '27-21',
                weather: 'Light Snow',
                injuries: '1 Out'
            }
        ];
    }
    
    setupBetSlip() {
        const betSlipToggle = document.getElementById('betSlipToggle');
        const closeBetSlip = document.getElementById('closeBetSlip');
        const betSlip = document.getElementById('betSlip');
        const clearBets = document.getElementById('clearBets');
        
        if (betSlipToggle) {
            betSlipToggle.addEventListener('click', () => {
                betSlip.classList.add('open');
            });
        }
        
        if (closeBetSlip) {
            closeBetSlip.addEventListener('click', () => {
                betSlip.classList.remove('open');
            });
        }
        
        if (clearBets) {
            clearBets.addEventListener('click', () => {
                this.clearBetSlip();
            });
        }
        
        // Update bet slip display
        this.updateBetSlipDisplay();
    }
    
    setupSportTabs() {
        const sportTabs = document.querySelectorAll('.sport-tab');
        
        sportTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs
                sportTabs.forEach(t => t.classList.remove('active'));
                
                // Add active class to clicked tab
                tab.classList.add('active');
                
                // Filter games by sport
                const sport = tab.dataset.sport;
                this.filterGamesBySport(sport);
            });
        });
    }
    
    filterGamesBySport(sport) {
        const games = document.querySelectorAll('.prediction-card');
        
        games.forEach(game => {
            if (sport === 'all') {
                game.style.display = 'block';
            } else {
                // In a real app, you'd filter by actual sport data
                game.style.display = 'block';
            }
        });
        
        // Animate filtered games
        anime({
            targets: '.prediction-card',
            scale: [0.9, 1],
            opacity: [0.7, 1],
            duration: 400,
            delay: anime.stagger(50),
            easing: 'easeOutQuad'
        });
    }
    
    initializeValueBets() {
        const valueBetsContainer = document.getElementById('valueBets');
        if (!valueBetsContainer) return;
        
        const valueBets = [
            {
                game: 'KC vs BUF',
                pick: 'KC -3.5',
                confidence: 78,
                reason: 'Strong home performance vs weak away defense'
            },
            {
                game: 'LAC vs DEN',
                pick: 'LAC -6.5',
                confidence: 65,
                reason: 'Denver struggling against division opponents'
            }
        ];
        
        valueBetsContainer.innerHTML = valueBets.map(bet => `
            <div class="flex justify-between items-center p-4 bg-charcoal rounded-lg">
                <div>
                    <div class="font-bold">${bet.pick}</div>
                    <div class="text-sm text-steel">${bet.game}</div>
                    <div class="text-xs text-steel mt-1">${bet.reason}</div>
                </div>
                <div class="text-right">
                    <div class="font-mono font-bold text-neon">${bet.confidence}%</div>
                    <div class="text-xs text-steel">Confidence</div>
                </div>
            </div>
        `).join('');
    }
    
    initializeLiveUpdates() {
        const liveUpdatesContainer = document.getElementById('liveUpdates');
        if (!liveUpdatesContainer) return;
        
        const liveUpdates = [
            {
                time: '2:30 PM',
                update: 'Line movement detected: KC -3.5 to -4.0',
                impact: 'Sharp money on Kansas City'
            },
            {
                time: '1:45 PM',
                update: 'Weather update: Light snow expected',
                impact: 'May favor running game'
            },
            {
                time: '12:15 PM',
                update: 'Injury report: BUF QB cleared to play',
                impact: 'Positive for Buffalo offense'
            }
        ];
        
        liveUpdatesContainer.innerHTML = liveUpdates.map(update => `
            <div class="flex items-start space-x-3 p-4 bg-charcoal rounded-lg">
                <div class="w-2 h-2 bg-neon rounded-full mt-2"></div>
                <div class="flex-1">
                    <div class="flex justify-between items-start mb-1">
                        <div class="font-medium">${update.update}</div>
                        <div class="text-xs text-steel">${update.time}</div>
                    </div>
                    <div class="text-sm text-steel">${update.impact}</div>
                </div>
            </div>
        `).join('');
    }
    
    // Analytics Page Features
    initializeAnalytics() {
        this.setupTeamComparison();
        this.initializeCharts();
        this.setupQueryInterface();
    }
    
    setupTeamComparison() {
        const teamASelector = document.getElementById('teamASelector');
        const teamBSelector = document.getElementById('teamBSelector');
        const teamModal = document.getElementById('teamSelectionModal');
        const closeTeamModal = document.getElementById('closeTeamModal');
        
        if (teamASelector) {
            teamASelector.addEventListener('click', () => {
                this.openTeamModal('A');
            });
        }
        
        if (teamBSelector) {
            teamBSelector.addEventListener('click', () => {
                this.openTeamModal('B');
            });
        }
        
        if (closeTeamModal) {
            closeTeamModal.addEventListener('click', () => {
                teamModal.classList.add('hidden');
            });
        }
        
        this.populateTeamList();
    }
    
    openTeamModal(team) {
        const modal = document.getElementById('teamSelectionModal');
        modal.classList.remove('hidden');
        modal.dataset.team = team;
    }
    
    populateTeamList() {
        const teamList = document.getElementById('teamList');
        if (!teamList) return;
        
        const teams = [
            'Kansas City Chiefs', 'Buffalo Bills', 'LA Chargers', 'Denver Broncos',
            'Green Bay Packers', 'Minnesota Vikings', 'Dallas Cowboys', 'Philadelphia Eagles',
            'San Francisco 49ers', 'Seattle Seahawks', 'Baltimore Ravens', 'Pittsburgh Steelers'
        ];
        
        teamList.innerHTML = teams.map(team => `
            <div class="p-3 bg-charcoal rounded-lg cursor-pointer hover:bg-gray-600 transition-colors" onclick="selectTeam('${team}')">
                ${team}
            </div>
        `).join('');
    }
    
    initializeCharts() {
        this.initializePerformanceChart();
        this.initializeRadarChart();
    }
    
    initializePerformanceChart() {
        const chartContainer = document.getElementById('performanceChart');
        if (!chartContainer) return;
        
        const chart = echarts.init(chartContainer);
        
        const option = {
            backgroundColor: 'transparent',
            textStyle: {
                color: '#ffffff'
            },
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(26, 26, 26, 0.9)',
                borderColor: '#00d4ff',
                textStyle: {
                    color: '#ffffff'
                }
            },
            legend: {
                data: ['Team A', 'Team B'],
                textStyle: {
                    color: '#ffffff'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: ['Game 1', 'Game 2', 'Game 3', 'Game 4', 'Game 5', 'Game 6', 'Game 7'],
                axisLine: {
                    lineStyle: {
                        color: '#6c757d'
                    }
                }
            },
            yAxis: {
                type: 'value',
                axisLine: {
                    lineStyle: {
                        color: '#6c757d'
                    }
                }
            },
            series: [
                {
                    name: 'Team A',
                    type: 'line',
                    data: [28, 31, 24, 35, 27, 33, 29],
                    lineStyle: {
                        color: '#00d4ff'
                    },
                    itemStyle: {
                        color: '#00d4ff'
                    }
                },
                {
                    name: 'Team B',
                    type: 'line',
                    data: [24, 28, 21, 26, 23, 29, 25],
                    lineStyle: {
                        color: '#ffa500'
                    },
                    itemStyle: {
                        color: '#ffa500'
                    }
                }
            ]
        };
        
        chart.setOption(option);
        
        // Resize chart on window resize
        window.addEventListener('resize', () => {
            chart.resize();
        });
    }
    
    initializeRadarChart() {
        const chartContainer = document.getElementById('radarChart');
        if (!chartContainer) return;
        
        const chart = echarts.init(chartContainer);
        
        const option = {
            backgroundColor: 'transparent',
            textStyle: {
                color: '#ffffff'
            },
            tooltip: {
                backgroundColor: 'rgba(26, 26, 26, 0.9)',
                borderColor: '#00d4ff',
                textStyle: {
                    color: '#ffffff'
                }
            },
            legend: {
                data: ['Team A', 'Team B'],
                textStyle: {
                    color: '#ffffff'
                }
            },
            radar: {
                indicator: [
                    { name: 'Offense', max: 100 },
                    { name: 'Defense', max: 100 },
                    { name: 'Special Teams', max: 100 },
                    { name: 'Coaching', max: 100 },
                    { name: 'Home Performance', max: 100 },
                    { name: 'Recent Form', max: 100 }
                ],
                axisName: {
                    color: '#ffffff'
                },
                splitLine: {
                    lineStyle: {
                        color: '#6c757d'
                    }
                },
                splitArea: {
                    show: false
                }
            },
            series: [{
                name: 'Team Comparison',
                type: 'radar',
                data: [
                    {
                        value: [85, 78, 82, 88, 92, 85],
                        name: 'Team A',
                        itemStyle: {
                            color: '#00d4ff'
                        }
                    },
                    {
                        value: [78, 85, 75, 82, 65, 78],
                        name: 'Team B',
                        itemStyle: {
                            color: '#ffa500'
                        }
                    }
                ]
            }]
        };
        
        chart.setOption(option);
        
        window.addEventListener('resize', () => {
            chart.resize();
        });
    }
    
    setupQueryInterface() {
        const executeQuery = document.getElementById('executeQuery');
        const aiQuery = document.getElementById('aiQuery');
        const filterButtons = document.querySelectorAll('.filter-button');
        
        if (executeQuery) {
            executeQuery.addEventListener('click', () => {
                this.executeAIQuery();
            });
        }
        
        if (aiQuery) {
            aiQuery.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.executeAIQuery();
                }
            });
        }
        
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const query = button.dataset.query;
                if (aiQuery) aiQuery.value = query;
                this.executeAIQuery();
            });
        });
    }
    
    executeAIQuery() {
        const query = document.getElementById('aiQuery').value;
        const resultsContainer = document.getElementById('queryResults');
        const contentContainer = document.getElementById('queryContent');
        
        if (!query.trim()) return;
        
        // Show loading state
        resultsContainer.classList.remove('hidden');
        contentContainer.innerHTML = '<div class="text-center py-8">AI is analyzing your query...</div>';
        
        // Simulate AI processing
        setTimeout(() => {
            const mockResults = this.generateMockQueryResults(query);
            contentContainer.innerHTML = mockResults;
            
            // Animate results
            anime({
                targets: '#queryResults',
                opacity: [0, 1],
                translateY: [20, 0],
                duration: 600,
                easing: 'easeOutQuad'
            });
        }, 1500);
    }
    
    generateMockQueryResults(query) {
        const results = [
            {
                game: 'Kansas City Chiefs vs Buffalo Bills',
                pick: 'Kansas City Chiefs -3.5',
                confidence: 78,
                reasoning: 'Strong home performance, superior offense metrics, and favorable weather conditions.'
            },
            {
                game: 'LA Chargers vs Denver Broncos',
                pick: 'LA Chargers -6.5',
                confidence: 65,
                reasoning: 'Denver struggling in division games, Chargers showing consistent home performance.'
            }
        ];
        
        return results.map(result => `
            <div class="p-4 bg-charcoal rounded-lg mb-4">
                <div class="flex justify-between items-start mb-2">
                    <div class="font-bold">${result.game}</div>
                    <div class="font-mono text-neon">${result.confidence}%</div>
                </div>
                <div class="text-electric mb-2">${result.pick}</div>
                <div class="text-sm text-steel">${result.reasoning}</div>
            </div>
        `).join('');
    }
    
    // Paper Trading Features
    initializePaperTrading() {
        this.setupBetModal();
        this.initializePortfolioChart();
        this.initializeStrategyChart();
        this.updatePortfolioStats();
        this.loadBetHistory();
    }
    
    setupBetModal() {
        const modal = document.getElementById('betModal');
        const closeModal = document.getElementById('closeBetModal');
        const cancelBet = document.getElementById('cancelBet');
        const betForm = document.getElementById('betForm');
        
        if (closeModal) {
            closeModal.addEventListener('click', () => {
                modal.classList.add('hidden');
            });
        }
        
        if (cancelBet) {
            cancelBet.addEventListener('click', () => {
                modal.classList.add('hidden');
            });
        }
        
        if (betForm) {
            betForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.placePaperBet();
            });
        }
        
        // Setup bet type change handlers
        const betTypeSelect = document.getElementById('betType');
        const gameSelection = document.getElementById('gameSelection');
        
        if (betTypeSelect) {
            betTypeSelect.addEventListener('change', () => {
                this.updateBetSelections();
            });
        }
        
        if (gameSelection) {
            gameSelection.addEventListener('change', () => {
                this.updateBetSelections();
            });
        }
        
        // Setup stake calculation
        const betStake = document.getElementById('betStake');
        if (betStake) {
            betStake.addEventListener('input', () => {
                this.calculatePotentialWin();
            });
        }
    }
    
    updateBetSelections() {
        const gameSelect = document.getElementById('gameSelection');
        const betTypeSelect = document.getElementById('betType');
        const selectionSelect = document.getElementById('betSelection');
        const oddsInput = document.getElementById('betOdds');
        
        if (!gameSelect || !betTypeSelect || !selectionSelect || !oddsInput) return;
        
        const game = gameSelect.value;
        const betType = betTypeSelect.value;
        
        // Clear previous options
        selectionSelect.innerHTML = '<option value="">Choose selection...</option>';
        
        if (!game) return;
        
        // Add appropriate selections based on bet type
        if (betType === 'moneyline') {
            selectionSelect.innerHTML += `
                <option value="home" data-odds="-150">Kansas City Chiefs (Win)</option>
                <option value="away" data-odds="+130">Buffalo Bills (Win)</option>
            `;
        } else if (betType === 'spread') {
            selectionSelect.innerHTML += `
                <option value="home-fav" data-odds="-110">Kansas City Chiefs -3.5</option>
                <option value="away-dog" data-odds="-110">Buffalo Bills +3.5</option>
            `;
        } else if (betType === 'total') {
            selectionSelect.innerHTML += `
                <option value="over" data-odds="-110">Over 51.5</option>
                <option value="under" data-odds="-110">Under 51.5</option>
            `;
        }
        
        // Setup selection change handler
        selectionSelect.addEventListener('change', () => {
            const selectedOption = selectionSelect.options[selectionSelect.selectedIndex];
            const odds = selectedOption.dataset.odds;
            oddsInput.value = odds;
            this.calculatePotentialWin();
        });
    }
    
    calculatePotentialWin() {
        const stakeInput = document.getElementById('betStake');
        const oddsInput = document.getElementById('betOdds');
        const potentialWinSpan = document.getElementById('potentialWin');
        
        if (!stakeInput || !oddsInput || !potentialWinSpan) return;
        
        const stake = parseFloat(stakeInput.value) || 0;
        const odds = oddsInput.value;
        
        if (!odds || stake <= 0) {
            potentialWinSpan.textContent = '$0.00';
            return;
        }
        
        let potentialWin = 0;
        
        if (odds.startsWith('+')) {
            // Positive odds
            const oddsValue = parseInt(odds.substring(1));
            potentialWin = stake * (oddsValue / 100);
        } else if (odds.startsWith('-')) {
            // Negative odds
            const oddsValue = parseInt(odds.substring(1));
            potentialWin = stake * (100 / oddsValue);
        }
        
        potentialWinSpan.textContent = `$${potentialWin.toFixed(2)}`;
    }
    
    placePaperBet() {
        const game = document.getElementById('gameSelection').value;
        const betType = document.getElementById('betType').value;
        const selection = document.getElementById('betSelection').value;
        const odds = document.getElementById('betOdds').value;
        const stake = parseFloat(document.getElementById('betStake').value);
        
        if (!game || !betType || !selection || !odds || stake <= 0) {
            alert('Please fill in all fields');
            return;
        }
        
        if (stake > this.paperTradingBalance) {
            alert('Insufficient funds');
            return;
        }
        
        // Create bet object
        const bet = {
            id: Date.now(),
            date: new Date().toLocaleDateString(),
            game: game,
            betType: betType,
            selection: selection,
            odds: odds,
            stake: stake,
            result: 'pending',
            profit: 0
        };
        
        // Add to bet history
        this.betHistory.unshift(bet);
        
        // Update balance
        this.paperTradingBalance -= stake;
        
        // Update displays
        this.updatePortfolioStats();
        this.loadBetHistory();
        this.updatePortfolioChart();
        
        // Close modal
        document.getElementById('betModal').classList.add('hidden');
        
        // Show success message
        this.showNotification('Bet placed successfully!', 'success');
    }
    
    initializePortfolioChart() {
        const chartContainer = document.getElementById('portfolioChart');
        if (!chartContainer) return;
        
        const chart = echarts.init(chartContainer);
        
        // Generate mock portfolio data
        const dates = [];
        const values = [];
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - 30);
        
        for (let i = 0; i < 30; i++) {
            const date = new Date(startDate);
            date.setDate(date.getDate() + i);
            dates.push(date.toLocaleDateString());
            
            // Simulate portfolio growth/decline
            const baseValue = 10000;
            const variation = Math.sin(i * 0.2) * 500 + Math.random() * 200 - 100;
            values.push(baseValue + variation);
        }
        
        const option = {
            backgroundColor: 'transparent',
            textStyle: {
                color: '#ffffff'
            },
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(26, 26, 26, 0.9)',
                borderColor: '#00d4ff',
                textStyle: {
                    color: '#ffffff'
                },
                formatter: function(params) {
                    return `${params[0].axisValue}<br/>Portfolio Value: $${params[0].value.toFixed(2)}`;
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                data: dates,
                axisLine: {
                    lineStyle: {
                        color: '#6c757d'
                    }
                },
                axisLabel: {
                    rotate: 45
                }
            },
            yAxis: {
                type: 'value',
                axisLine: {
                    lineStyle: {
                        color: '#6c757d'
                    }
                },
                axisLabel: {
                    formatter: '${value}'
                }
            },
            series: [{
                data: values,
                type: 'line',
                smooth: true,
                lineStyle: {
                    color: '#00d4ff',
                    width: 3
                },
                itemStyle: {
                    color: '#00d4ff'
                },
                areaStyle: {
                    color: {
                        type: 'linear',
                        x: 0,
                        y: 0,
                        x2: 0,
                        y2: 1,
                        colorStops: [{
                            offset: 0, color: 'rgba(0, 212, 255, 0.3)'
                        }, {
                            offset: 1, color: 'rgba(0, 212, 255, 0.05)'
                        }]
                    }
                }
            }]
        };
        
        chart.setOption(option);
        
        window.addEventListener('resize', () => {
            chart.resize();
        });
    }
    
    initializeStrategyChart() {
        const chartContainer = document.getElementById('strategyChart');
        if (!chartContainer) return;
        
        const chart = echarts.init(chartContainer);
        
        const option = {
            backgroundColor: 'transparent',
            textStyle: {
                color: '#ffffff'
            },
            tooltip: {
                trigger: 'item',
                backgroundColor: 'rgba(26, 26, 26, 0.9)',
                borderColor: '#00d4ff',
                textStyle: {
                    color: '#ffffff'
                }
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                textStyle: {
                    color: '#ffffff'
                }
            },
            series: [{
                name: 'Bet Types',
                type: 'pie',
                radius: '50%',
                data: [
                    { value: 60, name: 'Straight Bets', itemStyle: { color: '#00d4ff' } },
                    { value: 25, name: 'Parlays', itemStyle: { color: '#39ff14' } },
                    { value: 10, name: 'Props', itemStyle: { color: '#ffa500' } },
                    { value: 5, name: 'Live Bets', itemStyle: { color: '#ff6b6b' } }
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 212, 255, 0.5)'
                    }
                }
            }]
        };
        
        chart.setOption(option);
        
        window.addEventListener('resize', () => {
            chart.resize();
        });
    }
    
    updatePortfolioStats() {
        const bankrollElement = document.getElementById('virtualBankroll');
        const returnElement = document.getElementById('totalReturn');
        const winRateElement = document.getElementById('winRate');
        
        if (bankrollElement) {
            bankrollElement.textContent = `$${this.paperTradingBalance.toLocaleString()}`;
            
            // Add animation for balance changes
            bankrollElement.classList.add('bankroll-animation');
            setTimeout(() => {
                bankrollElement.classList.remove('bankroll-animation');
            }, 2000);
        }
        
        if (returnElement) {
            const initialBalance = 10000;
            const totalReturn = ((this.paperTradingBalance - initialBalance) / initialBalance) * 100;
            returnElement.textContent = `${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(1)}%`;
            returnElement.className = totalReturn >= 0 ? 'text-3xl font-orbitron font-bold text-neon mb-2' : 'text-3xl font-orbitron font-bold text-coral mb-2';
        }
        
        if (winRateElement) {
            const completedBets = this.betHistory.filter(bet => bet.result !== 'pending');
            const wins = completedBets.filter(bet => bet.result === 'win').length;
            const winRate = completedBets.length > 0 ? (wins / completedBets.length) * 100 : 0;
            winRateElement.textContent = `${winRate.toFixed(0)}%`;
        }
    }
    
    loadBetHistory() {
        const historyContainer = document.getElementById('betHistory');
        if (!historyContainer) return;
        
        if (this.betHistory.length === 0) {
            historyContainer.innerHTML = `
                <tr class="bet-history-item border-b border-gray-800">
                    <td class="py-3 px-4 text-sm text-steel" colspan="7">No bets yet. Start trading!</td>
                </tr>
            `;
            return;
        }
        
        historyContainer.innerHTML = this.betHistory.map(bet => `
            <tr class="bet-history-item border-b border-gray-800">
                <td class="py-3 px-4 text-sm text-steel">${bet.date}</td>
                <td class="py-3 px-4 text-sm">${bet.game}</td>
                <td class="py-3 px-4 text-sm text-steel">${bet.betType}</td>
                <td class="py-3 px-4 text-sm font-mono text-electric">${bet.odds}</td>
                <td class="py-3 px-4 text-sm font-mono">$${bet.stake}</td>
                <td class="py-3 px-4 text-sm">
                    <span class="px-2 py-1 rounded text-xs font-medium ${bet.result === 'win' ? 'win-badge' : bet.result === 'loss' ? 'loss-badge' : 'pending-badge'}">
                        ${bet.result}
                    </span>
                </td>
                <td class="py-3 px-4 text-sm font-mono ${bet.profit >= 0 ? 'text-neon' : 'text-coral'}">
                    ${bet.profit >= 0 ? '+' : ''}$${bet.profit.toFixed(2)}
                </td>
            </tr>
        `).join('');
    }
    
    updatePortfolioChart() {
        // In a real app, this would update the chart with new data
        // For now, we'll just reinitialize it
        this.initializePortfolioChart();
    }
    
    // Utility Functions
    startDataSimulation() {
        // Simulate real-time data updates
        setInterval(() => {
            this.updateOdds();
            this.updateLiveData();
        }, 10000); // Update every 10 seconds
        
        // Update predictions less frequently
        setInterval(() => {
            this.updatePredictions();
        }, 30000); // Update every 30 seconds
    }
    
    updateOdds() {
        // Simulate odds movement
        const oddsElements = document.querySelectorAll('.odds-display');
        oddsElements.forEach(element => {
            const currentOdds = element.textContent;
            // Add small random variation to odds
            const variation = (Math.random() - 0.5) * 0.2;
            // This is simplified - real implementation would be more complex
        });
    }
    
    updateLiveData() {
        // Update live game data
        // This would connect to real data sources in production
    }
    
    updatePredictions() {
        // Update AI predictions
        // This would run ML models in production
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 transform translate-x-full`;
        
        // Set notification style based on type
        switch (type) {
            case 'success':
                notification.classList.add('bg-neon', 'text-midnight');
                break;
            case 'error':
                notification.classList.add('bg-coral', 'text-white');
                break;
            case 'warning':
                notification.classList.add('bg-amber', 'text-midnight');
                break;
            default:
                notification.classList.add('bg-electric', 'text-midnight');
        }
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.classList.remove('translate-x-full');
        }, 100);
        
        // Animate out and remove
        setTimeout(() => {
            notification.classList.add('translate-x-full');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    // Global Functions (called from HTML)
    addToBetSlip(gameId, team) {
        // Add selection to bet slip
        const selection = {
            gameId,
            team,
            odds: team === 'home' ? '-150' : '+130' // Mock odds
        };
        
        this.betSlip.push(selection);
        this.updateBetSlipDisplay();
        this.showNotification('Added to bet slip!', 'success');
    }
    
    updateBetSlipDisplay() {
        const betCount = document.getElementById('betCount');
        const betSelections = document.getElementById('betSelections');
        const emptyBetSlip = document.getElementById('emptyBetSlip');
        const betSlipFooter = document.getElementById('betSlipFooter');
        
        if (betCount) {
            betCount.textContent = this.betSlip.length;
            betCount.classList.toggle('hidden', this.betSlip.length === 0);
        }
        
        if (this.betSlip.length === 0) {
            if (emptyBetSlip) emptyBetSlip.classList.remove('hidden');
            if (betSelections) betSelections.classList.add('hidden');
            if (betSlipFooter) betSlipFooter.classList.add('hidden');
            return;
        }
        
        if (emptyBetSlip) emptyBetSlip.classList.add('hidden');
        if (betSelections) betSelections.classList.remove('hidden');
        if (betSlipFooter) betSlipFooter.classList.remove('hidden');
        
        // Display bet selections
        if (betSelections) {
            betSelections.innerHTML = this.betSlip.map((selection, index) => `
                <div class="flex justify-between items-center p-3 bg-charcoal rounded-lg">
                    <div>
                        <div class="font-medium">${selection.team === 'home' ? 'Kansas City Chiefs' : 'Buffalo Bills'}</div>
                        <div class="text-sm text-steel">Moneyline</div>
                    </div>
                    <div class="text-right">
                        <div class="font-mono font-bold text-electric">${selection.odds}</div>
                        <button class="text-xs text-coral hover:underline" onclick="app.removeFromBetSlip(${index})">Remove</button>
                    </div>
                </div>
            `).join('');
        }
    }
    
    removeFromBetSlip(index) {
        this.betSlip.splice(index, 1);
        this.updateBetSlipDisplay();
        this.showNotification('Removed from bet slip', 'info');
    }
    
    clearBetSlip() {
        this.betSlip = [];
        this.updateBetSlipDisplay();
        this.showNotification('Bet slip cleared', 'info');
    }
}

// Global functions for HTML onclick handlers
function addToBetSlip(gameId, team) {
    if (window.app) {
        window.app.addToBetSlip(gameId, team);
    }
}

function selectTeam(teamName) {
    const modal = document.getElementById('teamSelectionModal');
    const team = modal.dataset.team;
    
    if (team === 'A') {
        const selector = document.getElementById('teamASelector');
        selector.querySelector('h3').textContent = teamName;
        selector.querySelector('p').textContent = 'Selected';
    } else {
        const selector = document.getElementById('teamBSelector');
        selector.querySelector('h3').textContent = teamName;
        selector.querySelector('p').textContent = 'Selected';
    }
    
    modal.classList.add('hidden');
}

function openBetModal(betType) {
    const modal = document.getElementById('betModal');
    const title = document.getElementById('modalTitle');
    
    const titles = {
        'straight': 'Place Straight Bet',
        'parlay': 'Place Parlay Bet',
        'props': 'Place Prop Bet',
        'live': 'Place Live Bet'
    };
    
    title.textContent = titles[betType] || 'Place Bet';
    modal.classList.remove('hidden');
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new SportsBettingApp();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
        // Resume updates when page becomes visible
        if (window.app) {
            window.app.startDataSimulation();
        }
    }
});